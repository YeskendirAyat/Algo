//
//  main.cpp
//  A
//
//  Created by  Yeskendir Ayat on 19.11.2020.
//
#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
int const N=10;
int m;
class Node {
    public:
    char data;
    Node *ch[N];
    int cnt;
    bool end;
    string city;
    Node (char data) {
        this->data = data;
        cnt=1;
        this->end=true;
        this->city="";
        for (int i = 0; i < N; i++) this->ch[i] = NULL;
    }
};
class Trie {
public:
    Node *root;
    Trie() { root = new Node(' '); }
    void insert(string number,string city){
        Node *cur=root;
        for (int i=0;i<(int)number.size(); i++) {
            if (cur->ch[number[i]-'0']!=NULL){
                cur=cur->ch[number[i]-'0'];
                cur->cnt++;
            }
            else{
                Node *node=new Node(number[i]);
                cur->ch[number[i]-'0']=node;
                cur=node;
            }
        }
        cur->end=true;
        cur->city=city;
    }
//    void search(Node *node, string s) {
//        if (s != "")
//            cout << s << " - " << node->cnt << endl;
//
//        for (int i = 0; i < N; i++)
//            if (node->ch[i] != NULL) {
//                search(node->ch[i], s + node->ch[i]->data);
//            }
//    }
//    int depth(Node *node,int d){
//        int dep=0;
//        for (int i=0; i<N; i++)
//            if (node->ch[i]!=NULL)
//                dep+=depth(node->ch[i],d);
//        return dep;
//    }
    int searchAll(Node *node,int depth) {
        int current_pow=pow(10, m-depth);
        int res=0;
        for (int i = 0; i < N; i++)
            if (node->ch[i] != NULL)
                res+=searchAll(node->ch[i], depth+1);
        if (node->end && node->city!=""){
            cout<<node->city<<" "<<current_pow-res<<endl;
            return current_pow;
        }
        return res;
    }
};


int main(){
//    freopen("output.txt", "w", stdout);
//    freopen("input.txt", "r", stdin);
    Trie *trie=new Trie();
    int n;  cin>>n>>m;
    string number,city;
    while (n--){
        cin>>number>>city;
        trie->insert(number,city);
    }
    trie->searchAll(trie->root,0);
}
//4 9
//831 NizhnyNovgorod
//8313 Dzerzhinsk
//83130 Sarov
//83144 Balakhna
