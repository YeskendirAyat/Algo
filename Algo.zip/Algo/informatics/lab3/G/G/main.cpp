//
//  main.cpp
//  G
//
//  Created by  Yeskendir Ayat on 9/20/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include <iostream>
#include <vector>
using namespace std;
bool b_search(vector<int> &v,int x){
    int low=0;
    int hight=v.size()-1;
    while (low<=hight) {
        int middle=(low+hight)>>1;
        if (x==v[middle])
            return true;
        else if(x<v[middle])
            hight=middle-1;
        else if(x>v[middle])
            low=middle+1;
    }
    return false;
}
int main(int argc, const char * argv[]) {
    int n,m;
    cin>>n>>m;
    vector<int> v(n);
    int b[m];
    for (int i=0; i<n; i++) {
        cin>>v[i];
    }
    for (int i=0; i<m; i++) {
        cin>>b[i];
    }
    for (int i=0; i<m; i++) {
        if (b_search(v,b[i]))
            cout<<"YES\n";
        else cout<<"NO\n";
    }
    return 0;
}
