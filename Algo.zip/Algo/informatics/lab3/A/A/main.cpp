#include <iostream>
#include <vector>
using namespace std;
int main(int argc, const char * argv[]){
    int n, k;
    cin >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++)
        cin >> v[i];
    cin>>k;
    for (int i = 0; i < n; i++){
        if (v[i]==k) {
            cout<<i+1<<" ";
        }
    }
    return 0;
}
