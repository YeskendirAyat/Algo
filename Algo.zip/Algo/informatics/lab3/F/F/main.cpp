//
//  main.cpp
//  K
//
//  Created by  Yeskendir Ayat on 7/13/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int t=*max_element(arr,arr+n);
    int q=*min_element(arr,arr+n);
    for(int i=0; i<n;i++){
        if(arr[i]==t){
            arr[i]=q;
        }
        cout<<arr[i]<<" ";
    }
    return 0;
}
