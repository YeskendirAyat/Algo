//
//  main.cpp
//  E
//
//  Created by  Yeskendir Ayat on 9/20/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <set>
#include <vector>
using namespace std;
int main(){
    int n;
    cin>>n;
    set<int> s;
    while(n>0){
        int x;
        cin>>x;
        s.insert(x);
        n--;
    }
    set<int>::iterator it = s.begin();
    set<int>::iterator it_end = s.end();
    vector<int> v(s.size());
    for (; it != it_end; ++it)
    {
        v.push_back(*it);
    }
    for(int i=v.size()-2;i < v.size()-1; i++){
        cout<<v[i]<<endl;
    }
    return 0;
}
