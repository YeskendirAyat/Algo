#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    cout<<(distance(arr, max_element(arr, arr + sizeof(arr)/sizeof(arr[0]))))+1 << "\n";
    return 0;
}
