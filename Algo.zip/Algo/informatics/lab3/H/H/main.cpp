//
//  main.cpp
//  H
//
//  Created by  Yeskendir Ayat on 9/20/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;
int main(int argc, const char * argv[]) {
    int n;
    cin>>n;
    cout<<ceil(log2(n));
    return 0;
}
