//
//  main.cpp
//  H
//
//  Created by  Yeskendir Ayat on 03.12.2020.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int n,m,x,y;
vector<int> g[100000];
int used[100000];
int used2[100000];
vector<int> v;
void dfs1(int k) {
    used[k] = 1;
    for (int i = 0; i < g[k].size(); i++) {
        y = g[k][i];
        if (used[y] == 0)
            dfs1(y);
        else if(used[y]==1){
            cout<<"No";
            exit(0);
        }
    }
    used[k]=2;
}
void dfs(int k) {
    used2[k] = 1;
    for (int i = 0; i < g[k].size(); i++) {
        y = g[k][i];
        if (used2[y] == 0)
            dfs(y);
    }
    v.push_back(k);
}
int main() {
    cin>>n>>m;
    for (int i = 0; i < m; i++) {
        cin >> x >> y;
        x--;
        y--;
        g[x].push_back(y);
    }
    for (int i = 0; i < n; i++)
        if (!used[i])
            dfs1(i);
    for (int i = 0; i < n; i++)
        if (!used2[i])
            dfs(i);
    cout<<"Yes\n";
    reverse(v.begin(),v.end());
    for (int i:v) cout <<i+1<<" ";
}
//4 4
//1 2
//2 3
//3 4
//1 4
