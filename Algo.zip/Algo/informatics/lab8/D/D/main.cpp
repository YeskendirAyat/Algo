//
//  main.cpp
//  D
//
//  Created by  Yeskendir Ayat on 03.12.2020.
//
#include<iostream>
#include<vector>
#include<queue>
using namespace std;
vector<int> g[100000];
int used[100000];
vector<int> res[100000];
int n,m,x,y;
void bfs(int x,int ord) {
    queue<int> q;
    res[ord].push_back(x);
    q.push(x);
    used[x]=1;
    while(!q.empty()) {
        int v=q.front();
        for(int i=0;i<g[v].size();i++){
            y=g[v][i];
            if(used[y]==0) {
                used[y]=1;
                res[ord].push_back(y);
                q.push(y);
            }
        }
        q.pop();
    }
}

int main() {
    cin>>n>>m;
    for(int i=0;i<m;i++) {
        cin>>x>>y;
        x--;
        y--;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    int cnt=0;
    for(int i=0;i<n;i++)
        if(used[i]==0) {
            bfs(i,cnt);
            cnt++;
        }
    cout<<cnt<<"\n";
    for(int i=0;i<cnt;i++) {
        cout<<res[i].size()<<"\n";
        for(int j=0;j<res[i].size();j++)
            cout<<res[i][j]+1<<" ";
        cout<<"\n";
    }
    return 0;
}
//6 4
//3 1
//1 2
//5 4
//2 3
