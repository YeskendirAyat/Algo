//
//  main.cpp
//  j2
//
//  Created by  Yeskendir Ayat on 04.12.2020.
//
#include<iostream>
#include<queue>
#include <algorithm>
#include <vector>
using namespace std;

int g_adj[100][100];
int used[100][100];
int d[100][100];
pair<int, int> path[100][100];
queue<pair<int,int> > q;
vector<int> g[100];
int dx[]={-1,1,2,2,1,-1,-2,-2};
int dy[]={2,2,1,-1,-2,-2,-1,1};
int n;
bool inBorder(int x,int y) {
    return (x<n && x>=0 && y<n && y>=0);
}
void bfs(int x,int y) {
    q.push({x,y});
    used[x][y]=1;
    d[x][y]=0;
    while(!q.empty()) {
        for(int i=0;i<8;i++) {
            int xx=q.front().first+dx[i],yy=q.front().second+dy[i];
            if(used[xx][yy]==0 && inBorder(xx,yy)) {
                used[xx][yy]=1;
                d[xx][yy]=d[q.front().first][q.front().second]+1;
//                cout<<x<<"-"<<y<<"   "<<xx<<"-"<<yy<<endl;
                path[xx][yy]={q.front().first,q.front().second};
                q.push({xx,yy});
            }
        }
        q.pop();
    }
}
vector<pair<int , int>> search(int x1,int y1){
    vector<pair<int , int>> answer;
    while (true){
        answer.push_back({x1, y1});
        if (d[x1][y1] == 0)
            break;
        for (int i=0; i<8; i++)
            if (x1 + dx[i] < n && x1 + dx[i] >= 0 && y1 + dy[i] < n && y1 + dy[i] >= 0)
                if (d[x1][y1] - 1 == d[x1 + dx[i]][y1 + dy[i]]) {
                    x1+=dx[i];
                    y1+=dy[i];
                    break;
                }
    }
    return answer;
}
int main() {
    int x0,y0,x1,y1;
    cin>>n>>x0>>y0>>x1>>y1; x0--; y0--; x1--; y1--;
    bfs(x0,y0);
    vector<pair<int , int >> v=search(x1,y1);
    reverse(v.begin(), v.end());
    cout<<d[x1][y1]<<endl;
    for (int i=0; i<v.size(); i++)
        cout<<v[i].first+1<<" "<<v[i].second+1<<endl;
//    cout<<d[x1][y1]<<endl;
//    cout<<path[x1][y1].first<<" "<<path[x1][y1].second<<endl;
//    for (int i=0; i<n; i++) {
//        for (int j=0; j<n; j++)
//            cout<<path[i][j].first<<"-"<<path[i][j].second<<" ";
//        cout<<endl;
//    }
    

    return 0;
}
//5
//3 3
//5 1
//
