//
//  main.cpp
//  G
//
//  Created by  Yeskendir Ayat on 03.12.2020.
//

#include <iostream>
#include <vector>
using namespace std;
int n, m;
int g[100][100];
bool used[100][100];
int dx[]={1,-1,0,0};
int dy[]={0,0,1,-1};
void dfs(int x,int y) {
    used[x][y] = true;
    for (int i = 0;i<4;i++) {
        int xx=x+dx[i],yy=y+dy[i];
        if (used[xx][yy] == false && ((xx>=0 and xx<n) && (yy<m and yy>=0)) && g[xx][yy]!=0)
            dfs(xx,yy);
    }
}
int main() {
    cin >> n >> m;
    for (int i = 0; i < n; i++)
        for(int j = 0; j < m; j++){
            char s; cin>>s;
            if (s!='.') g[i][j]=1;
            else g[i][j]=0;
        }
    int cnt = 0;
    for (int i = 0; i < n; i++)
        for (int j=0; j<m; j++)
            if (!used[i][j] && g[i][j]==1) {
                dfs(i,j);
                cnt++;
            }
    cout<<cnt<<endl;
    return 0;
}
//5 10
//##..#####.
//.#.#.#....
//###..##.#.
//..##.....#
//.###.#####
