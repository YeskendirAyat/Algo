//
//  main.cpp
//  K
//
//  Created by  Yeskendir Ayat on 05.12.2020.
//
#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;
int x,y,v,n=10000;
int d[10000],p[10000];
vector<int> g[100],path;
queue<int> q;
bool used[10000];
bool check(int n){
    int cnt=0,k=n;
    while(k!=0){
        if(k%10==0) cnt++;
        k/=10;
    }
    return n>1000 && n<10000 && !(cnt>0);
}
int main() {
    cin>>x>>y;
    q.push(x);
    used[x] = true;
    p[x] = -1;
    while (!q.empty()) {
        v = q.front();
        q.pop();
        int n1 = v+1000;
        if(check(n1))
            if (!used[n1]) {
                used[n1] = true;
                q.push(n1);
                d[n1] = d[v] + 1;
                p[n1] = v;
            }
        int n2 = v- 1;
        if(check(n2))
            if (!used[n2]){
                used[n2] = true;
                q.push(n2);
                d[n2] = d[v] + 1;
                p[n2] = v;
            }
        int n3 = (v%10)*1000 + v/10; //>>1
        if(check(n3))
            if (!used[n3]) {
                used[n3] = true;
                q.push(n3);
                d[n3] = d[v] + 1;
                p[n3] = v;
            }
        int n4 = (v - (v/1000)*1000)*10 + v/1000; ///<<1
        if(check(n4))
            if (!used[n4]) {
                used[n4] = true;
                q.push(n4);
                d[n4] = d[v] + 1;
                p[n4] = v;
            }
    }
    for (int v=y; v!=-1; v=p[v])
        path.push_back(v);
    reverse(path.begin(),path.end());
    for(int i:path)     cout<<i<<"\n";
    return 0;
}
//1234
//4321
//====
//1234
//2234
//3234
//4323
//4322
//4321
