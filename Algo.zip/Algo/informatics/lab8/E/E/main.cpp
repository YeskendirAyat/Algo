//
//  main.cpp
//  E
//
//  Created by  Yeskendir Ayat on 03.12.2020.
//
#include <iostream>
#include <vector>

using namespace std;
int n, m, x, y;
vector<int> g[100];
vector<int> g2[100];
int used[100];
bool isCicle=false;
void dfs(int v) {
    used[v] = 1;
    for (int i = 0; i < g[v].size(); i++) {
        y = g[v][i];
        if (used[y] == 0)
            dfs(y);
    }
}

int main() {
    cin >> n;
    for (int i = 0; i < n; i++)
        for (int j = 0;j< n; j++){
            cin>>x;
            if (x!=0){
                g[i].push_back(j);
                if (i>j)
                    g2[i].push_back(j);
            }
        }
    dfs(0);
    int cnt=0;
    for (int i=0; i<n; i++)
        if (!used[i]) {
            cout<<"NO";
            exit(0);
        }
    for (int i=0; i<n; i++)
//    1--2, 3
        cnt+=g2[i].size();
    if (cnt==n-1)
        cout<<"YES";
    else
        cout<<"NO";
    return 0;
}
//6
//0 1 1 0 0 0
//1 0 1 0 0 0
//1 1 0 0 0 0
//0 0 0 0 1 0
//0 0 0 1 0 0
//0 0 0 0 0 0

