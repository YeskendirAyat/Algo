//
//  main.cpp
//  В
//
//  Created by  Yeskendir Ayat on 03.12.2020.
//

#include<iostream>
#include<vector>
 
#define MAX 101
#define MAXN 1001
 
using namespace std;
 
int g[MAX][MAX];
 
int main() {
    int n,c,x=0,y=0,z=0;
    int bst=MAXN;
    cin>>n;
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++) cin>>g[i][j];
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            if(i!=j) {
                for(int k=0;k<n;k++) {
                    c=g[i][j]+g[j][k]+g[k][i];
 
                    if((k!=i && k!=j) && c<bst) {
                        bst=c;
                        x=i;
                        y=j;
                        z=k;
                    }
                }
            }
    cout<<x+1<<" "<<y+1<<" "<<z+1;
    return 0;
}
//
//5
//0 1 9 9 2
//1 0 9 9 9
//9 9 0 9 9
//9 9 9 0 9
//2 9 9 9 0
