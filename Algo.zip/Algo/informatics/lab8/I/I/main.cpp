//
//  main.cpp
//  I
//
//  Created by  Yeskendir Ayat on 04.12.2020.
//
// кратчайший путь
#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>
using namespace std;
int p[100],d[100];
int n,x,y,t;
vector<int> g[100],path;
queue<int> q;
bool used[100];
int main() {
    cin>>n;
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++){
            cin>>x;
            if(x!=0){
                g[i].push_back(j);
                g[j].push_back(i);}
        }
    cin>>x>>y; x--; y--;
    q.push(x);
    used[x] = true;
    p[x] = -1;
    while (!q.empty()) {
        int v = q.front();
        q.pop();
        for(int i=0;i<(int)g[v].size();i++){
            t = g[v][i];
            if (!used[t]) {
                used[t] = true;
                q.push(t);
                d[t] = d[v] + 1;
                p[t] = v;
            }
        }
    }
    if (!used[y]) cout << -1;
    else {
        for (int v=y; v!=-1; v=p[v])
            path.push_back(v);
        if(path.size()>1){
            cout << path.size()-1<<endl;
            reverse(path.begin(),path.end());
            for(int i:path)
                cout <<i+1<< " ";
        }
        else cout<<0;
    }
    return 0;
}
//5
//0 1 0 0 1
//1 0 1 0 0
//0 1 0 0 0
//0 0 0 0 0
//1 0 0 0 0
//3 5
