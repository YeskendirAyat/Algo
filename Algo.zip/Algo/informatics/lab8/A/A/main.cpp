//
//  main.cpp
//  A
//
//  Created by  Yeskendir Ayat on 03.12.2020.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main(int argc, const char * argv[]) {
    int n,cnt=0;  cin>>n;
    int a[n][n],b[n];
    for (int i=0; i<n; i++)
        for (int j=0;j<n; j++) cin>>a[i][j];
    for (int i=0; i<n; i++) cin>>b[i];
    for (int i=0; i<n; i++)
        for (int j=i;j<n; j++)
        if (a[i][j]!=0 && b[i]!=b[j])   cnt++;
    cout<<cnt;
    return 0;
}

//7
//0 1 0 0 0 1 1
//1 0 1 0 0 0 0
//0 1 0 0 1 1 0
//0 0 0 0 0 0 0
//0 0 1 0 0 1 0
//1 0 1 0 1 0 0
//1 0 0 0 0 0 0
//
//1 1 1 1 1 3 3
