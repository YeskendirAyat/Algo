#include <iostream>
#include <vector>
using namespace std;


bool b_search(vector<int> &v,int k){
    int r=v.size()-1;
    int l=0;
    while (l<=r) {
        int m=(l+r)/2;
        if (v[m]==k)
            return true;
        else if(v[m]>k)
            r=m-1;
        else if(v[m]<k)
            l=m+1;
    }
    return false;
}
int main(){
    int n,m,k;
    cin>>n>>m;
    int b[m];
    vector<int> v(n);
    for (int i=0; i<n; i++)
        cin>>v[i];
    for (int i=0; i<m; i++)
        cin>>b[i];
    for (int i=0; i<m; i++)
        if(b_search(v, b[i]))
            cout<<"Kaira found\n";
        else
            cout<<"Kaira cry\n";
    return 0;
}
