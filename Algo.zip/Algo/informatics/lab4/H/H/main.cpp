//
//  main.cpp
//  H
//
//  Created by  Yeskendir Ayat on 10/9/20.
//  Copyright © 2020 Macbook. All rights reserved.
#include <iostream>
#include <vector>
using namespace std;
vector<int> mv;
class Node{
public:
    int data;
    Node *left,*right;
    Node(int data){
        this->data=data;
        right=NULL;
        left=NULL;
    }
};
class BST{
public:
    Node *root;
    BST(){root=NULL;}
    Node *insert(Node *node,int data){
        if (node==NULL) {
            node=new Node(data);
            return node;}
        if (data<=node->data)
            node->left=insert(node->left, data);
        else
            node->right=insert(node->right, data);
        return node;
    }
    bool check(Node *node,int data){
        if (node==NULL) {
            return true;
        }
        while (node!=NULL) {
            if (node->data==data) {
                return false;
            }
            if (data<node->data)
                node=node->left;
            else if(data>node->data)
                node=node->right;
        }
        return true;
    }
    int size(Node *node){
        if (node==NULL)
            return 0;
        else
            return size(node->left)+size(node->right)+1;
    }
    void inOrder(Node *node){
        if (node==NULL) {
            return;
        }
        inOrder(node->left);

        if ((node->left==NULL && node->right!=NULL) || (node->left!=NULL && node->right==NULL))
            cout<<node->data<<"\n";
        inOrder(node->right);
    }
    
    bool checkAns(Node *node){
        if (node==NULL)
            return true;
        int l=Depth(node->left);
        int r=Depth(node->right);
        if(abs(r-l)<=1 && checkAns(node->left) && checkAns(node->right)) return true;
        else return false;
    }
    int Depth(Node *node){
        if (node == NULL)
            return 0;
        else{
            int lDepth = Depth(node->left);
            int rDepth = Depth(node->right);
            mv.push_back(max(lDepth,rDepth));
            return lDepth>rDepth ? lDepth+1 : rDepth+1;
        }
    }
    
    
};
int main(int argc, const char * argv[]) {
    BST *bst=new BST();
    int n;
    while (true){
        cin>>n;
        if (n==0)
            break;
        if (bst->check(bst->root, n))
            bst->root=bst->insert(bst->root,n);
    }
    if (bst->checkAns(bst->root))
        cout<<"YES";
    else cout<<"NO";
    return 0;
}
//7 3 2 1 9 5 4 6 8 0

