//
//  main.cpp
//  E
//
//  Created by  Yeskendir Ayat on 10/9/20.
//  Copyright © 2020 Macbook. All rights reserved.

#include <iostream>
using namespace std;
class Node{
public:
    int data;
    Node *left,*right;
    Node(int data){
        this->data=data;
        right=NULL;
        left=NULL;
    }
};
class BST{
public:
    Node *root;
    BST(){root=NULL;}
    Node *insert(Node *node,int data){
        if (node==NULL) {
            node=new Node(data);
            return node;}
        if (data<=node->data)
            node->left=insert(node->left, data);
        else
            node->right=insert(node->right, data);
        return node;
    }
    bool check(Node *node,int data){
        if (node==NULL) {
            return true;
        }
        while (node!=NULL) {
            if (node->data==data) {
                return false;
            }
            if (data<node->data)
                node=node->left;
            else if(data>node->data)
                node=node->right;
        }
        return true;
    }
    int size(Node *node){
        if (node==NULL)
            return 0;
        else
            return size(node->left)+size(node->right)+1;
    }
    void inOrder(Node *node){
        if (node==NULL) {
            return;
        }
        else
            if (node->left==NULL && node->right==NULL)
                cout<<node->data<<"\n";
        inOrder(node->left);
        inOrder(node->right);
    }
    int Depth(Node *node){
        if (node == NULL)
            return 0;
        else{
            int lDepth = Depth(node->left);
            int rDepth = Depth(node->right);
            return lDepth>rDepth ? lDepth+1 : rDepth+1;
        }
    }
    Node *findMin(Node *node){
        while (node->left!=NULL) { node=node->left; }
        return node;
    }
    Node *findMax(Node *node){
        while (node->right!=NULL) { node=node->right; }
        return node;
    }
    Node *findSecondMax(Node *node){
        if (size(root)==2)
            if (node->right==NULL)
                return node->left;
            else
                return node;
        else{
            while (node->right!=NULL) {
                if (node->right->right==NULL)
                    break;
                else
                    node=node->right;
            }
        }
        return node;
    }
    Node *deleteNode(Node *node,int data){
        if (node==NULL)
            return NULL;
        if (data<node->data)
            node->left=deleteNode(node->left, data);
        else if(data>node->data)
            node->right=deleteNode(node->right, data);
        else{
            if(node->right==NULL && node->left==NULL)
                node=NULL;
            else if(node->left==NULL && node->right!=NULL)
                node=node->right;
            else if(node->left!=NULL && node->right==NULL)
                node=node->left;
            else{
                Node *tmp=findMax(node->right);
                node->data=tmp->data;
                node->right=deleteNode(node->right, tmp->data);
            }
        }
        return node;
    }
};
int main(int argc, const char * argv[]) {
    BST *bst=new BST();
    int n;
    while (true){
        cin>>n;
        if (n==0)
            break;
        if (bst->check(bst->root, n))
            bst->root=bst->insert(bst->root,n);}
    bst->inOrder(bst->root);
    return 0;
}
