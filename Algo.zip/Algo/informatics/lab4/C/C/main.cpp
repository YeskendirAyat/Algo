//
//  main.cpp
//  C
//
//  Created by  Yeskendir Ayat on 10/9/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include <iostream>
#include <vector>
using namespace std;
vector<int> mv;
class Node{
public:
    int data;
    Node *left,*right;
    Node(int data){
        this->data=data;
        right=NULL;
        left=NULL;
    }
};
class BST{
public:
    Node *root;
    BST(){root=NULL;}
    Node *insert(Node *node,int data){
        if (node==NULL) {
            node=new Node(data);
            return node;}
        if (data<=node->data)
            node->left=insert(node->left, data);
        else
            node->right=insert(node->right, data);
        return node;
    }
    bool check(Node *node,int data){
        if (node==NULL) {
            return true;
        }
        while (node!=NULL) {
            if (node->data==data) {
                return false;
            }
            if (data<node->data)
                node=node->left;
            else if(data>node->data)
                node=node->right;
        }
        return true;
    }
    int size(Node *node){
        if (node==NULL)
            return 0;
        else
            return size(node->left)+size(node->right)+1;
    }
    Node *findMax(Node *node){
        while (node->right!=NULL) { node=node->right; }
        return node;
    }
//    Node *findSecondMax(Node *node){
//        if (node->right==NULL){
//            node=node->left;
//            return findMax(node);
//        }
//        else{
//            return findMax(node);
//        }
//        return node;
//    }
    void inOrder(Node *node){
        if (node==NULL)
            return;
        inOrder(node->left);
        mv.push_back(node->data);
        inOrder(node->right);
    }
};
int main(int argc, const char * argv[]) {
    BST *bst=new BST();
    int n;
    while (true){
        cin>>n;
        if (n==0)
            break;
        if (bst->check(bst->root, n))
            bst->root=bst->insert(bst->root,n);
    }
    bst->inOrder(bst->root);
    cout<<mv[bst->size(bst->root)-2];
}
//  1 2 3 4 5 6 7 8 9 10 11 0
