//
//  main.cpp
//  E
//
//  Created by  Yeskendir Ayat on 10/17/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
bool out=true;
class MaxHeap{
public:
    vector<int> a;
    int parent(int i){return (i-1)/2;}
    int left(int i){return (i*2)+1;}
    int right(int i){return (i*2)+2;}
    int getMax(){return a[0];}
    void insert(int n){
        a.push_back(n);
        int i=(int)a.size()-1;
        shiftUP(i);
    }
    void shiftUP(int i){
        if (i>(int)a.size())
            return;
        if (a[parent(i)]<a[i]){
            swap(a[parent(i)], a[i]);
            shiftUP(parent(i));
        }
        else
            if (out)
                cout<<i+1<<endl;
    }
    void shiftDOWN(int i){
        int swapId=i;
        if (left(i) <(int)a.size() && a[i]<a[left(i)])
            swapId=left(i);
        if (right(i)<(int)a.size()  && a[swapId]<a[right(i)])
            swapId=right(i);
        if (swapId!=i) {
            swap(a[i],a[swapId]);
            shiftDOWN(swapId);
        }
        else
            if (out)
            cout<<swapId+1<<" ";
    }
    int extractMax(){
        int maxNum=getMax();
        swap(a[0], a[(int)a.size()-1]);
        a.pop_back();
        if ((int)a.size()>0)
            shiftDOWN(0);
        if ((int)a.size()==0) {
            return 0;
        }
        return maxNum;
    }
    void delIndex(int i){
        if(i>=a.size() || i<0) {
            cout<<-1<<endl;
            return;
        }
        cout<<a[i]<<endl;
        if(a.size()==1) {
            a.pop_back();
            return;
        }
        swap(a[i],a[a.size()-1]);
        a.pop_back();
        shiftUP(i);
        shiftDOWN(i);
    }
};
int main(int argc, const char * argv[]) {
    MaxHeap *mxhp=new MaxHeap();
    int s,n;
    cin>>s>>n;
    while (n>0) {
        int x,t;
        cin>>x;
        if(x==1) {
            if (mxhp->a.size()==0)
                cout<<-1<<endl;
            else if(mxhp->a.size()==1){
                cout<<0<<" "<<mxhp->a[0]<<endl;
                mxhp->a.pop_back();
            }
            else{
                int b=mxhp->getMax();
                mxhp->extractMax();
                cout<<b<<endl;
            }
        }
        else if(x==2){
            cin>>t;
            if (s>(int)mxhp->a.size())
                mxhp->insert(t);
            else
                cout<<-1<<endl;
        }
        else{
            cin>>t;
            t-=1;
            if (mxhp->a.empty())
                cout<<-1<<endl;
            else{
                out=false;
                mxhp->delIndex(t);
            }
        }
        out=true;
        n--;
    }
    for (int i=0; i<(int)mxhp->a.size(); i++)
        cout<<mxhp->a[i]<<" ";
}
//4 10
//1
//2 9
//2 4
//2 9
//2 9
//2 7
//1
//3 4
//2 1
//3 3
