//
//  main.cpp
//  F
//
//  Created by  Yeskendir Ayat on 10/16/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
class MaxHeap{
public:
    vector<int> a;
    int parent(int i){return (i-1)/2;}
    int left(int i){return (i*2)+1;}
    int right(int i){return (i*2)+2;}
    int getMax(){return a[0];}
    void insert(int n){
        a.push_back(n);
        int i=(int)a.size()-1;
        shiftUP(i);
    }
    void shiftUP(int i){
        if (i>(int)a.size())
            return;
        if (a[parent(i)]<a[i]){
            swap(a[parent(i)], a[i]);
            shiftUP(parent(i));
        }
    }
    void shiftDOWN(int i){
        int swapId=i;
        if (left(i) <(int)a.size() && a[i]<a[left(i)])
            swapId=left(i);
        if (right(i)<(int)a.size()  && a[swapId]<a[right(i)])
            swapId=right(i);
        if (swapId!=i) {
            swap(a[i],a[swapId]);
            shiftDOWN(swapId);
        }
        else
            cout<<swapId+1<<" ";
    }
    
    int extractMax(){
        int maxNum=getMax();
        swap(a[0], a[(int)a.size()-1]);
        a.pop_back();
        if ((int)a.size()>0)
            shiftDOWN(0);
        if ((int)a.size()==0) {
            return 0;
        }
        return maxNum;
    }
};
int main(int argc, const char * argv[]) {
    MaxHeap *mxhp=new MaxHeap();
    int n,x;
    cin>>n;
    int k=n;
    while(k>0){
        cin>>x;
        mxhp->insert(x);
        k--;
    }
    for (int i=0; i<(int)mxhp->a.size(); i++)
        cout<<mxhp->a[i]<<" ";
    return 0;
}
//6
//1 2 3 4 5 6
