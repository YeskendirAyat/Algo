//
//  main.cpp
//  H
//
//  Created by  Yeskendir Ayat on 10/17/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class MaxHeap{
public:
    vector<int> a;
    int parent(int i){return (i-1)/2;}
    int left(int i){return (i*2)+1;}
    int right(int i){return (i*2)+2;}
    int getMax(){return a[0];}
    void insert(int n){
        a.push_back(n);
    }
    void shiftUP(int i){
        if (i>(int)a.size())
            return;
        if (a[parent(i)]<a[i]){
            swap(a[parent(i)], a[i]);
            shiftUP(parent(i));
        }
    }
    int extractMax(){
        int maxNum=getMax();
        swap(a[0], a[(int)a.size()-1]);
        a.pop_back();
        if ((int)a.size()>0)
            shiftDOWN(0);
        return maxNum;
    }
    void print(){
        for (int i=0; i<(int)a.size(); i++)
            cout<<a[i]<<" ";
        cout<<endl;
    }
    void shiftDOWNmain(){
        for (int i=(int)a.size()/2-1; i>=0; i--) shiftDOWN(i);
    }
    void shiftDOWN(int i){
        if (i>(int)a.size())
            return;
        int swapId=i;
        if (left(i) <(int)a.size() && a[i]<a[left(i)])
            swapId=left(i);
        if (right(i)<(int)a.size()  && a[swapId]<a[right(i)])
            swapId=right(i);
        if (swapId!=i) {
            swap(a[i],a[swapId]);
            shiftDOWN(swapId);
        }
    }
};
int main(int argc, const char * argv[]) {
    MaxHeap *mxhp=new MaxHeap();
    int n;
    cin>>n;
    int a[n];
    for (int i=0; i<n; i++) cin>>a[i];
    for (int i=0; i<n; i++) mxhp->insert(a[i]);
    for (int i=n-1; i>=0; i--){
        mxhp->shiftDOWNmain();
        mxhp->print();
        a[i]=mxhp->extractMax();

    }
    for (int i=0; i<n; i++)
        cout<<a[i]<<" ";
}


