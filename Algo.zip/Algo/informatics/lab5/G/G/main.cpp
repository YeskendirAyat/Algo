//
//  main.cpp
//  G
//
//  Created by  Yeskendir Ayat on 10/17/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class MaxHeap{
public:
    vector<int> a;
    int parent(int i){return (i-1)/2;}
    int left(int i){return (i*2)+1;}
    int right(int i){return (i*2)+2;}
    int getMax(){return a[0];}
    void insert(int n){
        a.push_back(n);
    }
    void shiftUP(int i){
        if (i>(int)a.size())
            return;
        if (a[parent(i)]<a[i]){
            swap(a[parent(i)], a[i]);
            shiftUP(parent(i));
        }
    }
    void shiftDOWN(int i){
        if (i>(int)a.size())
            return;
        int swapId=i;
        if (left(i) <(int)a.size() && a[i]<a[left(i)])
            swapId=left(i);
        if (right(i)<(int)a.size()  && a[swapId]<a[right(i)])
            swapId=right(i);
        if (swapId!=i) {
            swap(a[i],a[swapId]);
            shiftDOWN(swapId);
        }
    }
};
int main(int argc, const char * argv[]) {
    MaxHeap *mxhp=new MaxHeap();
    int n,x;
    cin>>n;
    int k=0;
    while(k<n){
        cin>>x;
        mxhp->insert(x);
        k++;
    }
    for (int i=(int)mxhp->a.size()/2-1; i>=0; i--)
        mxhp->shiftDOWN(i);
    for (int i=0; i<(int)mxhp->a.size(); i++)
        cout<<mxhp->a[i]<<" ";
}
//6
//1 2 3 4 5 6
