#include <iostream>
using namespace std;
class Node {
    public:
    int data;
    Node *next, *prev;
    Node(int data) {
        this->data = data;
        this->next = NULL;
        this->prev = NULL;
    }
};
class Deque {
    public:
    Node *front, *tail;
    int sz;
    Deque() {
        front = NULL;
        tail = NULL;
        sz=0;
    }
    void push_back(int data) {
        Node *node = new Node(data);
        if (tail == NULL) {
            front = node;
            tail = node;
        } else {
            tail->next = node;
            node->prev = tail;
            tail = node;
        }
        cout<<"ok\n";
        sz+=1;
    }
    void push_front(int data) {
        Node *node = new Node(data);
        if (front == NULL) {
            front = node;
            tail = node;
        } else {
            node->next = front;
            front->prev = node;
            front = node;
        }
        cout<<"ok\n";
        sz+=1;
    }
    void pop_back() {
        if (tail == NULL){
            cout<<"error\n";
            return;
        }
        cout<<tail->data<<"\n";
        tail = tail->prev;
        if (tail != NULL)
            tail->next = NULL;
        else
            front = NULL;
        sz-=1;
    }
    void pop_front() {
        if (front == NULL){
             cout<<"error\n";
            return;
        }
        cout<<front->data<<"\n";
        front = front->next;
        if (front != NULL)
            front->prev = NULL;
        else
            tail = NULL;
        sz-=1;
    }
    void getfront(){
        if (front == NULL){
             cout<<"error\n";
        }
        else cout<<front->data<<"\n";
    }
    void getback(){
        if (front == NULL){
             cout<<"error\n";
        }
        else
            cout<<tail->data<<"\n";
    }
    void clear() {
        Node *node = front;
        while (node != NULL) {
            node = node->next;
            front=node;
        }
        sz=0;
        cout << "ok\n";
    }
    int size(){
        return sz;
    }
};
int main() {
    Deque *dq= new Deque();
    string s;
    int a;
    while (true) {
        cin>>s;
        if (s=="exit") {
            cout<<"bye";
            break;
        }
        else if (s=="push_front") {
            cin>>a;
            dq->push_front(a);
        }
        else if (s=="push_back") {
            cin>>a;
            dq->push_back(a);
        }
        else if (s=="pop_front")
            dq->pop_front();
        else if (s=="pop_back")
            dq->pop_back();
        else if (s=="clear")
            dq->clear();
        else if (s=="front")
            dq->getfront();
        else if (s=="back")
            dq->getback();
        else if (s=="size")
            cout<<dq->size()<<"\n";
    }

    return 0;
}
