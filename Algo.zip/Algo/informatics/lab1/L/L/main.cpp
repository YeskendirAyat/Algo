#include <iostream>
#include <cmath>
using namespace std;

long Ans(long a, long b){
    for (long i=a; i<a*b; i++) {
        if(i%a==0 && i%b==0){
            return i;
            break;
        }
    }
    return a*b;
}
void Deffind(long a,long b){
    if(a>b)
        cout<<Ans(a,b);
    else
        cout<<Ans(b,a);
}
int main(int argc, const char * argv[]) {
    long a,b;
    cin>>a>>b;
    Deffind(a, b);
    return 0;
}
