//
//  main.cpp
//  G2
//
//  Created by  Yeskendir Ayat on 9/19/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <stack>
#include <sstream>
using namespace std;
int main(int argc, const char * argv[]) {
    stack<int> st;
    int a,b;
    while(cin) {
        string s;
        cin>>s;
        if(s!="+" && s!="-" && s!="*") {
            stringstream geek(s);
            int x = 0;
            geek >> x;
            st.push(x);
        } else {
            if(s=="+") {
                b=st.top();
                st.pop();
                a=st.top();
                st.pop();
                st.push(a+b);
            }
            else if(s=="-") {
                b=st.top();
                st.pop();
                a=st.top();
                st.pop();
                st.push(a-b);
            }
            else if(s=="*") {
                b=st.top();
                st.pop();
                a=st.top();
                st.pop();
                st.push(a*b);
            } else {
                break;
            }
        }
    }
    st.pop();
    cout<<st.top();
    return 0;
}

