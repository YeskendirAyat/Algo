//
//  main.cpp
//  H
//
//  Created by  Yeskendir Ayat on 9/20/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include<iostream>
#include <queue>
using namespace std;
int main(){
    deque<int> dq1,dq2;
    int n;
    cin >> n;
    char sign;
    while(n--){
        cin >> sign;
        if(sign == '+'){
            int x;
            cin >> x;
            dq2.push_back(x);
        }
        else if(sign == '*'){
            int x;
            cin >> x;
            dq2.push_front(x);
        }
        else if(sign=='-'){
            cout << dq1.front() << endl;
            dq1.pop_front();
        }
        if(dq2.size()>dq1.size()){
            dq1.push_back(dq2.front());
            dq2.pop_front();
        }
    }
    return 0;
}
