#include <iostream>
#include <queue>
using namespace std;
int main(){
    queue <int> q1,q2;
    int n=0,x;
    for (int i = 0 ; i< 5;i++){
        cin>>x;
        q1.push(x);
    }
    for (int i = 0 ; i< 5;i++){
        cin>>x;
        q2.push(x);
    }
    while (true){
        if(n==10e6 || q1.empty() || q2.empty()){
            break;
        }
        if (q1.front()>q2.front()){
            if (q1.front()==9 and q2.front()==0){
                q2.push(q1.front());
                q2.push(q2.front());
                q1.pop();
                q2.pop();
            }
            else{
                q1.push(q1.front());
                q1.push(q2.front());
                q1.pop();
                q2.pop();
            }
        }
        else{
            if (q2.front()==9 and q1.front()==0){
                q1.push(q1.front());
                q1.push(q2.front());
                q1.pop();
                q2.pop();
            }
            else{
                q2.push(q1.front());
                q2.push(q2.front());
                q1.pop();
                q2.pop();
            }
        }
        n++;
    }
    if (n==10e6)
        cout<<"botva\n";
    else if (q2.empty())
        cout<<"first "<<n;
    else
        cout<<"second "<<n;
    return 0;
}
