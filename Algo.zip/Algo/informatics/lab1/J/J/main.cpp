//
//  main.cpp
//  J
//
//  Created by  Yeskendir Ayat on 9/17/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
//
#include <iostream>
using namespace std;
int GCD(int a, int b){
    while (a>0 && b>0) {
        if(a>b)
            a=a%b;
        else
            b=b%a;
    }
    return a+b;
}
int main(int argc, const char * argv[]) {
    int a,b;
    cin>>a>>b;
    cout<<GCD(a, b);
    return 0;
}
