#include <iostream>
using namespace std;
class Node {
    public:
    int data;
    Node *next, *prev;

    Node(int data) {
        this->data = data;
        this->next = NULL;
        this->prev = NULL;
    }
};
class Queue {
    public:
    Node *front, *tail;
    int sz;
    Queue() {
        front = NULL;
        tail = NULL;
        sz=0;
    }
    void push(int data) {
        Node *node = new Node(data);
        if (tail == NULL) {
            cout<<"ok\n";
            front = node;
            tail = node;
            sz+=1;
        } else {
            cout<<"ok\n";
            tail->next = node;
            node->prev = tail;
            tail = node;
            sz+=1;

        }
    }
    void pop() {
        if (front == NULL){
            cout<<"error\n";
            return;
        }
        cout<<front->data<<endl;
        front = front->next;
        sz-=1;
        if (front != NULL){
            front->prev=NULL;
        }
        else{
            tail = NULL;
        }
    }
    void pop2() {
        if (front == NULL){
            
            return;
        }
        front = front->next;
        if (front != NULL){
            front->prev=NULL;
        }
        else{
            tail = NULL;
        }
    }
    void size(){
        cout<<sz<<endl;
    }
    void clear() {
//        if (front==NULL) {
//            cout<<"error\n";
//            return;
//        }
        while(sz!=0){
            pop2();
            sz-=1;
        }
        cout<<"ok\n";
    }
    void getFront(){
        if(front==NULL){
            cout<<"error\n";
            return;
        }
        cout<<front->data<<endl;
    }
};

int main() {
    Queue *q = new Queue();
    while (true) {
        string s;
        cin>>s;
        int num;
        if (s=="exit") {
            cout<<"bye";
            break;
        }
        if (s=="push") {
            cin>>num;
            q->push(num);
        }
        if (s=="pop") {
            q->pop();
        }
        if (s=="front") {
            q->getFront();
        }
        if (s=="size") {
            q->size();
        }
        if (s=="clear") {
            q->clear();
        }
    }

    return 0;
}
