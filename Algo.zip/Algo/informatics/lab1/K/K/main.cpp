//
//  main.cpp
//  K
//
//  Created by  Yeskendir Ayat on 9/17/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;
bool Prime(int a){
    for (int i=2; i<=sqrt(a); i++) {
        if (a%i==0)
            return false;
    }
    return true;
}
int main(int argc, const char * argv[]) {
    int a;
    cin>>a;
    if(Prime(a))
        cout<<"prime";
    else cout<<"composite";
    return 0;
}
