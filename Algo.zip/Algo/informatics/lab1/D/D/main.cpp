#include<iostream>
#include<vector>
using namespace std;
int main() {
    int year;
    string surename;
    vector<pair<int,string> > clas9,clas10,clas11;
    while(cin>>year) {
        cin>>surename;
        if(year==9)
            clas9.push_back(make_pair(9,surename));
        else if(year==10)
            clas10.push_back(make_pair(10,surename));
        else if(year==11)
            clas11.push_back(make_pair(11,surename));
    }
    for(int i=0;i<clas9.size();i++) {
        cout<<clas9[i].first<<" "<<clas9[i].second<<"\n";
    }
    for(int i=0;i<clas10.size();i++) {
        cout<<clas10[i].first<<" "<<clas10[i].second<<"\n";
    }
    for(int i=0;i<clas11.size();i++) {
        cout<<clas11[i].first<<" "<<clas11[i].second<<"\n";
    }
    return 0;
}
