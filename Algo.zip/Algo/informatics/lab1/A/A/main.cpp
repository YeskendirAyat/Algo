#include <iostream>
using namespace std;
class Node {
    public:
    int data;
    Node *next;
    Node(int data) {
        this->data = data;
        this->next = NULL;
    }
};
class Stack {
    public:
    Node *top;
    int sz;
    Stack() {
        top = NULL;
        sz = 0;
    }
    void push(int data) {
        Node *node = new Node(data);
        node->next = top;
        top = node;
        sz++;
        cout<<"ok\n";
    }
    void pop() {
        cout<<top->data<<"\n";
        top = top->next;
        sz--;
    }
    int size() {
        return this->sz;
    }
    bool empty() {
         if (sz == 0)
             return true;
         else
             return false;
    }
    void clear() {
        while (sz>0) {
            top = top->next;
            sz--;
        }
        cout<<"ok\n";
    }
    void back(){
        if(sz==0){
            cout<<"error"<<"\n";
        }
        else
            cout<<top->data<<"\n";
    }
};
int main() {
    Stack *st = new Stack();
    while (true) {
        string s;
        cin>>s;
        int num;
        if(s=="exit"){
            cout<<"bye";
            break;
        }
        else if (s=="pop")
            if(st->empty())
                cout<<"error\n";
            else
                st->pop();
        else if (s=="size")
            cout<<st->size()<<"\n";
        else if (s=="back")
            if(st->empty())
                cout<<"error\n";
            else
                st->back();
        else if (s=="clear")
            st->clear();
        else if(s=="push"){
            cin>>num;
            st->push(num);
        }
    }
    return 0;
}
