//
//  main.cpp
//  I
//
//  Created by  Yeskendir Ayat on 9/20/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include <iostream>
#include <vector>
using namespace std;
int upper_bound_bin_search(vector<int> &a, int x) {
    int l = 0;
    int r = a.size() - 1;
    while (l < r - 1){
        int m = (l + r) / 2;
        if (a[m] <= x)
            l = m;
        else
            r = m - 1;
    }
    if (a[r] == x)
        return r+1;
    else if (a[l] == x)
        return l+1;
    else
        return 0;
}
int lower_bound_bin_search(vector<int> &a, int x) {
    int l = 0;
    int r = a.size() -1;
    while (l != r){
        int m = (l + r) >>1;
        if (a[m] < x)
            l = m + 1;
        else
            r = m;
    }
    if (a[l] == x)
        return l+1;
    else
        return 0;
}
int main() {
    int n, m;
    cin >> n >> m;
    vector<int> a(n);
    int b[m];
    for (int i = 0;i < n; i++)
        cin >> a[i];
    for (int i=0; i<m; i++)
        cin>>b[i];
    for (int i=0; i<m; i++) {
        int x=upper_bound_bin_search(a,b[i]);
        if (x!=0)
            cout<<lower_bound_bin_search(a,b[i])<<" "<<x<<endl;
        else
            cout<<x<<endl;
    }
    return 0;
}
