//
//  main.cpp
//  C
//
//  Created by  Yeskendir Ayat on 11/6/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include<iostream>
#include<algorithm>
#include<vector>
#define ll long long
using namespace std;
vector<long long> pws(1e6);
ll getHash(string s,int n) {
    ll result=0;
    for(int i=0;i<n;i++)
        result+=(s[i]-'a'+1)*pws[i];
    return result;
}
vector<ll> getHashes(string s,int n) {
    vector<ll> hash(n);
    for(ll i=0;i<n;i++) {
        hash[i]=(s[i]-'a'+1)*pws[i];
        if(i)
            hash[i]+=hash[i-1];
    }
    return hash;
}
string f(string s){
    string s1="",s2="";
    s2+=s[(int)s.size()-1];
    for (int i=0; i<s.size()-1; i++)
        s1+=s[i];
    return s2+s1;
}

int main() {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0)),cout.tie(0);
    pws[0]=1;
    for(ll i=1;i<=1e6;i++)
        pws[i]=pws[i-1]*31;
    string first,second;   cin>>first>>second;
    ll run=(int)first.size(),cnt=0;
    vector<ll> second_hash=getHashes(second,(int)second.size());
    while (run--){
        vector<ll> first_hashes=getHashes(first,(int)first.size());
        bool find=true;
        for(ll i=0;i<=(int)(first.size());i++)
            if (first[i]!=second[i])
                find=false;
        if (find) {
            cout<<cnt;
            exit(0);
        }
        first=f(first);
        cnt++;
    }
    cout<<-1;
    return 0;
}

