//
//  main.cpp
//  A
//
//  Created by  Yeskendir Ayat on 11/6/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include<iostream>
#include<algorithm>
#include<vector>
#define ll long long
using namespace std;
vector<long long> pws(50000);
ll getHash(string s,int n) {
    ll result=0;
    for(int i=0;i<n;i++)
        result+=(s[i]-'a'+1)*pws[i];
    return result;
}
vector<ll> getHashes(string s,int n) {
    vector<ll> hash(n);
    for(ll i=0;i<n;i++) {
        hash[i]=(s[i]-'a'+1)*pws[i];
        if(i)
            hash[i]+=hash[i-1];
    }
    return hash;
}
int main() {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0)),cout.tie(0);
    pws[0]=1;
    for(ll i=1;i<=50000;i++)
        pws[i]=pws[i-1]*31;
    string first,second;
    cin>>first>>second;
    vector<ll> first_hashes=getHashes(first,(int)first.size());
    ll second_hash=getHash(second,(int)second.size());
    for(ll i=0;i<=(int)(first.size()-second.size());i++) {
        ll cur_hash=first_hashes[i+second.size()-1];
        if(i)
            cur_hash-=first_hashes[i-1];
        if(cur_hash==second_hash*pws[i])
            cout<<i<<" ";
    }
    return 0;
}

