//
//  main.cpp
//  B
//
//  Created by  Yeskendir Ayat on 11/6/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
vector<int> prefix_function(string s){
    vector<int> v((int)s.size(),0);
    for (int i=1; i<(int)s.size(); i++) {
        int j=v[i-1];
        while (j>0 && s[i]!=s[j])
            j=v[j-1];
        if (s[i]==s[j])
            j++;
        v[i]=j;
    }
    return v;
}
int main(int argc, const char * argv[]) {
    ios::sync_with_stdio(0);
    string s;   cin>>s;
    int k=(int)s.size();
    vector<int> v=prefix_function(s);
    int n=v[s.size()-1];
    int c=k-n;
    if (k%c==0)
        cout<<k/c;
    else
        cout<<1;
    return 0;
}
