//
//  main.cpp
//  Stack
//
//  Created by  Yeskendir Ayat on 9/5/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include<iostream>
#include<stack>
#include<string>
#include<sstream>

using namespace std;

int main(int argc, const char * argv[]) {
    stack<char> st;
    string s;

    cin>>s;

    for(int i=0;i<s.size();i++) {
        if(s[i]=='(') {
            st.push('(');
        }
        else if(s[i]=='[') {
            st.push('[');
        }
        else if(s[i]=='{') {
            st.push('{');
        }

        if(s[i]==')') {
            if(!st.empty()) {
                if(st.top()=='(') {
                    st.pop();
                }
                else {
                    cout<<"no";
                    exit(0);
                }
            }
            else {
                cout<<"no";
                exit(0);
            }
        }
        else if(s[i]==']') {
            if(!st.empty()) {
                if(st.top()=='[') {
                    st.pop();
                }
                else {
                    cout<<"no";
                    exit(0);
                }
            }
            else {
                cout<<"no";
                exit(0);
            }
        }
        else if(s[i]=='}') {
            if(!st.empty()) {
                if(st.top()=='{') {
                    st.pop();
                }
                else {
                    cout<<"no";
                    exit(0);
                }
            }
            else {
                cout<<"no";
                exit(0);
            }
        }
    }

    if(st.empty()) {
        cout<<"yes";
    }
    else {
        cout<<"no";
    }


    return 0;
}
