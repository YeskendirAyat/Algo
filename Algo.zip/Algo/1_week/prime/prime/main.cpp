//
//  main.cpp
//  prime
//
//  Created by  Yeskendir Ayat on 9/5/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
// by Erotosphen
#include <iostream>
using namespace std;
int main(int argc, const char * argv[]) {
    
    return 0;
}
