//
//  main.cpp
//  efclid
//
//  Created by  Yeskendir Ayat on 9/5/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;
int gcd(int a,int b){
    if (b==0) {
        return a;
    }
    else{
        return gcd(b, a%b);
    }
}

int main(int argc, const char * argv[]) {
    int a,b;
    cin>>a>>b;
    int ma = max(a,b);
    int mi = min(a,b);
    cout<<gcd(mi,ma);
    return 0;
}
