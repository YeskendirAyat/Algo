//
//  main.cpp
//  F
//
//  Created by  Yeskendir Ayat on 9/5/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;
bool Check(string in){
    stack<char> st;
    for(int i=1;i<=in.size();i++){
        if(in[i]=='('){
            st.push('(');
        }
        else if (in[i]=='['){
            st.push('[');
        }
        else if(in[i]=='{'){
            st.push('{');
        }
    }
    return false;
}
int main(int argc, const char * argv[]) {
    string in;
    cin>>in;
    cout<<Check(in);
    return 0;
}
