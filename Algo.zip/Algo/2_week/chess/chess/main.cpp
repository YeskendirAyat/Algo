//
//  main.cpp
//  chess
//
//  Created by  Yeskendir Ayat on 9/12/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <queue>
using namespace std;
int a[10][10];
st
int main(int argc, const char * argv[]) {
    
    return 0;
}
