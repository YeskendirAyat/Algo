//
//  main.cpp
//  draft
//
//  Created by  Yeskendir Ayat on 9/12/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <queue>
using namespace std;

queue<pair<int, int> > q;
int used[1000];
int c[1000];

int f(int a, int b){
    q.push(make_pair(a,0));
    used[a]=1;
    c[a] = a;
    while(!q.empty()){
        int x = q.front().first;
        int d = q.front().second;

        if(x == b){
            return d;
        }

        if(used[x+1] == 0){
            q.push(make_pair(x+1,d+1));
            used[x+1] = 1;
            c[x+1] = x;
        }
        
        if(used[x*2] == 0){
            q.push(make_pair(x*2,d+1));
            used[x*2] = 1;
            c[x*2] = x;
        }

        if(used[x/2] == 0){
            q.push(make_pair(x/2,d+1));
            used[x/2] = 1;
            c[x/2] = x;
        }

        if(x-1>=0&&used[x-1] == 0){
            q.push(make_pair(x-1,d+1));
            used[x-1] = 1;
            c[x-1] = x;
        }
        q.pop();
        return 0;

    }
}

int main(){
    int a,b;

    cin >>a >> b;
    int d = f(a,b);
    cout << d << endl;
    int i = b;
    while(d--){
        cout << i << " ";
        i =c[i];
    }


    return 0;
}
