//
//  main.cpp
//  A
//
//  Created by  Yeskendir Ayat on 10/31/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;
int main(int argc, const char * argv[]) {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(static_cast<void>(cin.tie(0)),cout.tie(0));
    int n;  cin>>n;
    cout<<n;
    
    return 0;
}

