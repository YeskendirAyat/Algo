//
//  main.cpp
//  Hash
//
//  Created by  Yeskendir Ayat on 11/7/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#define ll long long
using namespace std;
vector<ll> hash_(string s){
    vector<ll> result(s.size());
    
    return result;
}
ll getHash(string s){
    ll result=0;
    int prime=31;
    for (int i=0; i<(int)s.size(); i++)
        result+=(ll)(s[i]-'a'+1)*pow(prime,i);
    return result;
}
int main(int argc, const char * argv[]){
    string first;    cin>>first;
//    cout<<getHash(first);
    int i1,i2,len;  cin>>i1>>i2>>len;
//    int j1=
    return 0;
}
