//
//  main.cpp
//  A
//
//  Created by  Yeskendir Ayat on 19.11.2020.
//

#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#define ll long long
using namespace std;
int main(int argc, const char * argv[]) {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0));
    int n;  cin>>n;
    vector<int> v(n);
    for (int i=0; i<n; i++)
        cin>>v[i];
    cout<<char(v[0]+97);
    for (int i=1; i<v.size(); i++)
        cout<<char(((v[i]-v[i-1])/pow(2,i))+97);
    return 0;
}
