//
//  main.cpp
//  B
//
//  Created by  Yeskendir Ayat on 19.11.2020.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
vector<int> prefix_function(string s) {
    int n = (int)s.size();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int j = p[i - 1];
        while (j > 0 && s[j] != s[i])
            j = p[j - 1];
        if (s[j] == s[i])
            j++;
        p[i] = j;
    }
    return p;
}
int search(string s,vector<string> porol){
    int cnt=0;
    for (int i=0; i<porol.size(); i++) {
        string check=s+"#"+porol[i];
        vector<int> v=prefix_function(check);
        for (int i=0; i<v.size(); i++) {
            if (v[i]==s.length()){
                cnt++;
                break;
            }
        }
    }
    return cnt;
}


int main(int argc, const char * argv[]) {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0));
    int n,m;    cin>>n>>m;
    vector<string> porol(n);
    vector<string> key(m);
    for (int i=0; i<n; i++) cin>>porol[i];
    for (int i=0; i<m; i++) cin>>key[i];
    for (int i=0; i<m; i++) {
        cout<<search(key[i],porol)<<"\n";
    }
    

    return 0;
}

//4 2
//september
//october
//november
//december
//ber
//mber


//4 4
//stay
//hungry
//stay
//foolish
//stay
//tay
//ay
//y
