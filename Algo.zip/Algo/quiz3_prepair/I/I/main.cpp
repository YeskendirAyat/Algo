//
//  main.cpp
//  I
//
//  Created by  Yeskendir Ayat on 19.11.2020.
//
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
using namespace std;
vector<int> prefix_function(string s) {
    int n = (int)s.size();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int j = p[i - 1];
        while (j > 0 && s[j] != s[i])
            j = p[j - 1];
        if (s[j] == s[i])
            j++;
        p[i] = j;
    }
    return p;
}
bool check(string s,vector<string> v1){
    for (int i=0; i<v1.size(); i++){
        string fnl=v1[i]+"#"+s;
        vector<int> prf=prefix_function(fnl);
        int in=(int)v1[i].length()+(int)v1[i].length()+1;
        if (prf[(int)v1[i].length()*2]==v1[i].length() && s.length()>v1[i].length())
            return true;
    }
    return false;
}
int main(int argc, const char * argv[]) {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0));
    int n,m;  cin>>n>>m;
    vector<string> v1(n);
    vector<string> v2(m);
    for (int i=0; i<n; i++) cin>>v1[i];
    for (int i=0; i<m; i++) cin>>v2[i];
    for (int i=0; i<v2.size(); i++) {
        if (check(v2[i], v1)) cout<<"Yes\n";
        else cout<<"No\n";
    }
    return 0;
}

//3 5
//747
//8702
//9
//747697289
//870
//722678
//87021234567
//9
