//
//  main.cpp
//  G
//
//  Created by  Yeskendir Ayat on 19.11.2020.
//
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
vector<int> prefix_function(string s) {
    int n = (int)s.length();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int j = p[i - 1];
        while (j > 0 && s[j] != s[i])
            j = p[j - 1];
        if (s[j] == s[i])
            j++;
        p[i] = j;
    }
    return p;
}
string search(string word,string find){
    string fnl=find+"#"+word;
    vector<int> v=prefix_function(fnl);
    for (int i=(int)find.length()+1; i<v.size(); i++) {
        if (v[i]==find.size()) {
            int n=i-(int)find.length();
            word.erase(word.begin()+(n)-(int)find.length(),word.begin()+(n));
            return word;
        }
    }
    return word;
}
int main() {
    string s;   cin>>s;
    int n;  cin>>n;
    vector<string> v(n);
    for (int i=0; i<n; i++) cin>>v[i];
    for (int i=0; i<n; i++) {
        s=search(s,v[i]);
        if (s.empty()) {
            cout<<"YES";
            exit(0);
        }
    }
    cout<<"NO";
//    cout<<s;
    return 0;
}

//goldenwind
//2
//golden
//wind

//goldenwind
//2
//goldenw
//wind


//jojoreference
//5
//jojo
//reference
//lol
//kek
//d
