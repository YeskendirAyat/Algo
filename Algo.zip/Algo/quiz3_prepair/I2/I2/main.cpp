//
//  main.cpp
//  I2
//
//  Created by  Yeskendir Ayat on 20.11.2020.
//

#include <iostream>
#include <vector>
using namespace std;
int const N=10;

class Node{
public:
    Node *ch[N];
    char data;
    int cnt;
    bool end;
    Node(char data){
        this->data=data;
        this->end=false;
        for (int i=0; i<N; i++) ch[i]=NULL;
        cnt=1;
    }
};
// ASCII 0->47 ... 9->57
class Trie{
public:
    Node *root;
    Trie(){ root=new Node(' '); }
    void insert(string s){
        Node *cur=root;
        for (int i=0;i<s.length(); i++) {
            if (cur->ch[s[i]-'0']!=NULL){
                cur=cur->ch[s[i]-'0'];
                cur->cnt++;
            }
            else{
                Node *node=new Node(s[i]);
                cur->ch[s[i]-'0']=node;
                cur=node;
            }
        }
        cur->end=true;
    }
    void search(Node *node,string s){
        if (node->end)
            cout<<node->data<<endl;
        for (int i=0; i<N; i++) {
            if (node->ch[i]!=NULL) {
                search(node->ch[i], s+node->ch[i]->data);
            }
        }
    }
    bool searchAns(string s) {
        Node *cur = root;
        for (int i = 0; i < s.length(); i++) {
            if (cur->ch[s[i] - '0'] == NULL)
                return false;
            if (cur->ch[s[i] - '0']->end)
                return true;
            cur = cur->ch[s[i] - '0'];
        }
        return false;
    }
};

int main(int argc, const char * argv[]) {
    Trie *trie=new Trie();
    int n,m;  cin>>n>>m;
    string s;
    for (int i=0; i<n; i++){
        cin>>s;
        trie->insert(s);
    }
    while (m--) {
        cin>>s;
        s.pop_back();
        if (trie->searchAns(s))
            cout<<"Yes\n";
        else cout<<"No\n";
    }
    return 0;
}
//3 5
//747
//8702
//9
//747697289
//870
//722678
//87021234567
//9

