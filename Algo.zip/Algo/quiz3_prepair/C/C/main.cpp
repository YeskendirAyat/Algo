//
//  main.cpp
//  C
//
//  Created by  Yeskendir Ayat on 19.11.2020.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

vector<int> prefix_function(string s) {
    int n = (int)s.size();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int j = p[i - 1];
        while (j > 0 && s[j] != s[i])
            j = p[j - 1];
        if (s[j] == s[i])
            j++;
        p[i] = j;
    }
    return p;
}

int main(int argc, const char * argv[]) {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0));
    string first,second;    cin>>first>>second;
    string fnl=second+"#"+first;
    vector<int> v=prefix_function(fnl);
    int in=v[v.size()-1];
    for (int i=0; i<first.size()-in; i++)
        cout<<first[i];
    cout<<second;
    return 0;
    
}
//pen pineapple
//pineapple apple
//pineapple lemon
