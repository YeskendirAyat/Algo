//
//  main.cpp
//  F
//
//  Created by  Yeskendir Ayat on 19.11.2020.
//
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
vector<int> prefix_function(string s){
    vector<int> v((int)s.size(),0);
    for (int i=1; i<(int)s.size(); i++) {
        int j=v[i-1];
        while (j>0 && s[i]!=s[j])
            j=v[j-1];
        if (s[i]==s[j])
            j++;
        v[i]=j;
    }
    return v;
}
vector<pair<int, string>> searchAll(vector<string> v, string s){
    vector<pair<int, string>> new_v;
    int max=0;
    for (int i=0; i<v.size(); i++) {
        string v_s=v[i];
        string fnl=v_s+"#"+s;
        vector<int> mv=prefix_function(fnl);
        int cnt=0;
        for (int i = (int)v_s.length()+1; i < mv.size(); i++)
            if (mv[i] == v_s.size())
                cnt++;
        if(cnt>max)
            max=cnt;
        new_v.push_back({cnt,v_s});
    }
    new_v.push_back({max,"Max Value"});
    return new_v;
}

int main(int argc, const char * argv[]) {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0));
    while (true) {
        int n;  cin>>n;
        if (n==0)   exit(0);
        vector<string> v;
        string s;
        for (int i=0; i<n; i++) {
            cin>>s;
            v.push_back(s);
        }
        cin>>s;
        vector<pair<int, string>> fnl_v=searchAll(v,s);
        cout<<fnl_v[fnl_v.size()-1].first<<endl;
        for (int i=0; i<fnl_v.size()-1; i++)
            if (fnl_v[i].first==fnl_v[fnl_v.size()-1].first)
                cout<<fnl_v[i].second<<"\n";
    }
    return 0;
}

//2
//aba
//bab
//ababababac
//6
//beta
//alpha
//haha
//delta
//dede
//tata
//dedeltalphahahahototatalpha
