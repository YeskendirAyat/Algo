//
//  main.cpp
//  K
//
//  Created by  Yeskendir Ayat on 20.11.2020.
//
#include <iostream>
#include <string>
using namespace std;
char a[10000000];

void quicksort(int l, int r) {
    int i = l;
    int j = r;
    char p = a[(l + r) / 2];
    while (i < j) {
        while (a[i] < p) i++;
        while (a[j] > p) j--;
        if (i <= j) {
            swap(a[i], a[j]);
            i++;
            j--;
        }
    }
    if (l < j)
        quicksort(l, j);
    if (i < r)
        quicksort(i, r);
}
int main() {
    string first;   cin>>first;
    for (int i = 0; i < first.length(); i++)
        a[i]=first[i];
    string first_uppers="";
    quicksort(0, (int)first.length() - 1);
    for (int i = 0; i < first.length(); i++)
        if (a[i]=='A' || a[i]=='O' || a[i]=='E' || a[i]=='U' || a[i]=='I')
            first_uppers+=a[i];
    cin>>first;
    for (int i = 0; i < first.length(); i++)
        a[i]=first[i];
    string second_uppers="";
    quicksort(0, (int)first.length() - 1);
    for (int i = 0; i < first.length(); i++)
        if (a[i]=='A' || a[i]=='O' || a[i]=='E' || a[i]=='U' || a[i]=='I')
            second_uppers+=a[i];
//    cout<<first_uppers<<"\n"<<second_uppers;
    if (first_uppers==second_uppers)  cout<<"YES";
    else    cout<<"NO";
    return 0;
}

//potAto
//tomAto

