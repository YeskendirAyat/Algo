//
//  main.cpp
//  J
//
//  Created by  Yeskendir Ayat on 20.11.2020.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;
vector<int> prefix_function(string s){
    vector<int> v((int)s.size(),0);
    for (int i=1;i<(int)s.size(); i++) {
        int j=v[i-1];
        while (j>0 && s[i]!=s[j]){
            j=v[j-1];
        }
        if (s[i]==s[j])
            j++;
        v[i]=j;
    }
    return v;
}
int main(int argc, const char * argv[]) {
    ios::sync_with_stdio(0);
    string s,s2;   cin>>s>>s2;
    if (s==s2) {
        cout<<0;
        exit(0);
    }
    bool ans=false;
    s=s2+"#"+s+s;
    vector<int> v=prefix_function(s);
    for (int i=(int)s2.size()+1;i<(int)v.size();i++)
        if (v[i]==(int)s2.size()){
            cout<<(int)s.size()-i-1<<endl;
            ans=true;
            break;
        }
    if (!ans) {
        cout<<-1;
    }
    return 0;
}
