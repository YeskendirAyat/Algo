//
//  main.cpp
//  H
//
//  Created by  Yeskendir Ayat on 19.11.2020.

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
using namespace std;
vector<int> prefix_function(string s) {
    int n = (int)s.size();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int j = p[i - 1];
        while (j > 0 && s[j] != s[i])
            j = p[j - 1];
        if (s[j] == s[i])
            j++;
        p[i] = j;
    }
    return p;
}
vector<pair<string,int>> check(string s,vector<string> v){
    vector<pair<string,int>> new_v;
    int mx=0;
    for (int i=0; i<v.size(); i++) {
        string fnl=v[i]+"#"+s;
        vector<int> prf=prefix_function(fnl);
        int cnt=prf[prf.size()-1];
        if (cnt>mx) mx=cnt;
        new_v.push_back({v[i],cnt});
    }
    new_v.push_back({"Max Value",mx});
    return new_v;
}
int main(int argc, const char * argv[]) {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0));
    string city;    cin>>city;
    int n;  cin>>n;
    string s;
    vector<string> v;
    for (int i=0; i<n; i++){
        cin>>s;
        s[0]=tolower(s[0]);
        v.push_back(s);
    }
    vector<pair<string,int>> ans=check(city, v);
    int cnt=0;
    string list="";
    for(int i=0; i<ans.size()-1; i++){
        ans[i].first[0]=toupper(ans[i].first[0]);
        if (ans[i].second==ans[ans.size()-1].second){
            cnt++;
            list+=ans[i].first+"\n";
        }
    }
    cout<<cnt<<"\n"<<list;
    return 0;
}
//Kokshetau
//5
//Astana
//Tauemel
//Tainan
//Almaty
//Budapest
