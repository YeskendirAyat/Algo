//
//  main.cpp
//  D
//
//  Created by  Yeskendir Ayat on 19.11.2020.

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
vector<int> prefix_prefix(string s){
    vector<int> v((int)s.size(),0);
    for (int i=1; i<(int)s.size(); i++) {
        int j=v[i-1];
        while (j>0 && s[i]!=s[j]){
            j=v[j-1];
        }
        if (s[i]==s[j])
            j++;
        v[i]=j;
    }
    return v;
}

int main(int argc, const char * argv[]) {
    ios::sync_with_stdio(0);
    string first,second;   cin>>first>>second;
    string fnl=first+"#"+second;
    vector<int> v=prefix_prefix(fnl);
    int mx=0 , cnt=0, step=0;
    for (int i=0; i<v.size(); i+=step) {
        if (v[i]==first.length()) {
            cnt++;
            step=(int)first.length();
        }
        
        else{
            cnt=0;
            step=1;
        }
        mx=max(mx,cnt);
    }
    cout<<mx;
    return 0;
}
//aba
////ababaaba
//
//[Forwarded from Алмас Брат]
//#include<iostream>
//#include<vector>
//#include<algorithm>
//
//#define ll long long
//
//using namespace std;
//
//void computePows(vector<ll> &pows) {
//    pows[0]=1;
//
//    for(int i=1;i<pows.size();i++) {
//        pows[i]=pows[i-1]*31;
//    }
//}
//
//ll hashOfString(string s, vector<ll> pows) {
//    ll res=0;
//
//    for(int i=0;i<s.size();i++) {
//        res+=s[i]*pows[i];
//    }
//
//    return res;
//}
//
//vector<ll> hashes(string s,vector<ll> pows) {
//    vector<ll> res(s.size());
//
//    res[0]=s[0];
//
//    for(int i=1;i<s.size();i++) {
//        res[i]=res[i-1]+s[i]*pows[i];
//    }
//
//    return res;
//}
//
//ll findMax(vector<ll>& v) {
//    ll mx=v[0];
//
//    for(int i=1;i<v.size();i++) {
//        if(mx<v[i]) {
//            mx=v[i];
//        }
//    }
//
//    return mx;
//}
//
//int main() {
//    string s,t;
//    cin>>s>>t;
//
//    vector<ll> pws(t.size());
//    computePows(pws);
//
//    vector<ll> all_hashes=hashes(t,pws);
//    vector<ll> rs(t.size());
//    ll s_hash=hashOfString(s,pws);
//
//    int x=0;
//    int k=1;
//    ll cnt=0;
//    rs[0]=0;
//    ll cur_hash;
//
//    while(x+s.size()<=t.size()) {
//        cur_hash=all_hashes[x+s.size()-1];
//        if(x) {
//            cur_hash-=all_hashes[x-1];
//        }
//
//        if(cur_hash==s_hash*pws[x]) {
//            x+=s.size();
//            cnt++;
//
//            cur_hash=all_hashes[x+s.size()-1];
//            if(x) {
//                cur_hash-=all_hashes[x-1];
//            }
//
//            if(cur_hash!=s_hash*pws[x]) {
//                rs[k++]=cnt;
//                cnt=0;
//                x-=s.size()-1;
//            }
//        } else {
//            rs[k++]=cnt;
//            cnt=0;
//            x++;
//        }
//    }
//    rs[k++]=cnt;
//
//    cout<<findMax(rs);
//
//
//    return 0;
//}
