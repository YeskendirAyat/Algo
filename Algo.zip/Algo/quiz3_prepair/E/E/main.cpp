//
//  main.cpp
//  E
//
//  Created by  Yeskendir Ayat on 19.11.2020.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
vector<char> f(vector<char> v){
    vector<char> new_v;
    for (int i=0; i<v.size(); i++)
//        vowels  A, E, I, O, U
        if (v[i]!='a' && v[i]!='A' && v[i]!='e' && v[i]!='E' && v[i]!='i' && v[i]!='I' && v[i]!='o' && v[i]!='O' && v[i]!='u' && v[i]!='U')
            new_v.push_back(v[i]);
    return new_v;
}
int main(int argc, const char * argv[]) {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0));
    string s;   cin>>s;
    vector<char> v(s.length()/2);
    vector<char> v2(s.length()/2);
    for (int i=0; i<(int)s.length(); i++){
        if (i<(int)s.length()/2)
            v2.push_back(s[i]);
        else v.push_back(s[i]);
    }
    vector<char> v3=f(v2);
    for(auto i:v3) cout<<i;
    for (int i=(int)v.size()-1; i>0; i--) cout<<v[i];
    cout<<endl;
    return 0;
}

//0VxrJXx7BM
// j1g9U1umMm
// xDwSbKNPhk
// Z0UMi9Uees
//0VxrJMB7xX
