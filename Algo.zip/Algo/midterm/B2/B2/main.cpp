//
//  main.cpp
//  B2
//
//  Created by  Yeskendir Ayat on 10/24/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
bool sort_check(pair<int, pair<int,int> > a,pair<int, pair<int,int> > b) {
    if(a.second.second>b.second.second)  return true;
    else if(a.second.second==b.second.second && a.second.first>b.second.first)  return true;
    else if(a.second.second==b.second.second && a.second.first==b.second.first && a.first>b.first)  return true;
    return false;
}
int main() {
    int n,d,m,y;  cin>>n;
    vector<pair<int, pair<int,int> > > mv;
    while (n--) {
        cin>>d>>m>>y;
        mv.push_back(make_pair(d,make_pair(m,y)));
    }
    for(int i=0;i<mv.size();i++)
        for(int j=0;j<mv.size()-1;j++)
            if(sort_check(mv[j],mv[j+1]))
                swap(mv[j],mv[j+1]);
    for(int i=0;i<mv.size();i++)
        cout<<mv[i].first<<" "<<mv[i].second.first<<" "<<mv[i].second.second<<"\n";
    return 0;
}
