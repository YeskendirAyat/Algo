//
//  main.cpp
//  D
//
//  Created by  Yeskendir Ayat on 10/24/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include<iostream>
#include<vector>

using namespace std;

class MaxHeap{
    public:
    vector<int> a;
    //find index of parent какого то элемента:
    int parent(int i){
        return (i-1) / 2;
    }
    //find index of left child:
    int left(int i){
        return 2 * i + 1;
    }
    //find index of right child:
    int right(int i){
        return 2 * i + 2;
    }
    //minimum:
    int getMax(){
        return a[0];
    }
    void insert(int k){
        a.push_back(k);
        siftUp((int)a.size() - 1);
        // cout << siftUp(a.size() - 1) << endl;
    }
    int heapify(int i) {
        if(left(i) > a.size() - 1) {
            return i;
        }
        int temp = left(i);
        if(right(i) < a.size() && a[left(i)] < a[right(i)]) temp = right(i);
        if(a[i] < a[temp]){
            swap(a[i],a[temp]);
            return heapify(temp);
        }
        return i;
    }
    int siftUp(int i){
        while(i >= 0 && a[parent(i)] < a[i]){
            swap(a[parent(i)], a[i]);
            i = parent(i);
        }
        return i;
    }

    int deleteMax(){
        int root_value = getMax();
        swap(a[0], a[a.size()-1]);
        a.pop_back();
//        int h = heapify(0);
        return root_value;
    }
};
int main(){
    MaxHeap h;
    int n;
    cin >> n;
    for(int i = 0; i < n; i++){
        int x;
        cin >> x;
        h.insert(x);
        if(i < 2){
            cout << -1 << endl;
        }
        else{
            long long maxi1 = h.deleteMax(), maxi2 = h.deleteMax(),maxi3 =h.deleteMax();
            cout << maxi1*maxi2*maxi3 << endl;
            h.insert(maxi1);
            h.insert(maxi2);
            h.insert(maxi3);
        }
    }
    return 0;
}
