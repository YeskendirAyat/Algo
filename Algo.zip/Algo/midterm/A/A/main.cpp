////
////  main.cpp
////  A
////
////  Created by  Yeskendir Ayat on 10/24/20.
////  Copyright © 2020 Macbook. All rights reserved.
////
//
//#include <iostream>
//#include <vector>
//#include <cmath>
//
//using namespace std;
//
//int main(int argc, const char * argv[]) {
//    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0)),cout.tie(0);
//    int n;  cin>>n;
//    while (n--) {
//        cin
//    }
//    return 0;
//}
