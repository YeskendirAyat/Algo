//
//  main.cpp
//  F
//
//  Created by  Yeskendir Ayat on 10/24/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;
vector<int> v;
void merge_sort(int *a,int l, int r){
    if (l<r){
        int m = (l+r)/2;
        v.push_back(a[m]);
        merge_sort(a,l,m);
        merge_sort(a,m+1,r);
    }
}
int main(int argc, const char * argv[]) {
    int t;  cin>>t;
    int n=pow(2,t)-1;
    int a[n];
    for (int i=0; i<n; i++) cin>>a[i];
    sort(a,a+n);
    merge_sort(a,0,n-1);
    v.push_back(a[n-1]);
    for(auto i:v)   cout<<i<<" ";
    return 0;
}
