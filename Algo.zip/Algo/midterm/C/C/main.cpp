//
//  main.cpp
//  C
//
//  Created by  Yeskendir Ayat on 10/24/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
using namespace std;
char a[100000];
void quicksort(int l, int r) {
    int i = l;
    int j = r;
    char p = a[(l + r) / 2];

    while (i < j) {
        while (a[i] < p) i++;
        while (a[j] > p) j--;
        if (i <= j) {
            swap(a[i], a[j]);
            i++;
            j--;
        }
    }
    if (l < j)
        quicksort(l, j);
    if (i < r)
        quicksort(i, r);
}
int main(int argc, const char * argv[]) {
    char b[5]={'a','e','i','o','u'};
    int n;  cin>>n;
    string s;   cin>>s;
    for (int i=0; i<s.size(); i++)
        a[i]=s[i];
    quicksort(0, n-1);
    for (int i=0;i<5; i++) {
        for (int j=0; j<n; j++) {
            if (b[i]==a[j]) {
                cout<<a[j];
                a[j]='0';
            }
        }
    }
    for (int i=0; i<n; i++) {
        if (a[i]!='0') {
            cout<<a[i];
        }
    }
    
    return 0;
}

// a, e, i, o, u.
