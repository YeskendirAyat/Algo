//
//  main.cpp
//  B
//
//  Created by  Yeskendir Ayat on 21.11.2020.
//

#include <iostream>
#include <vector>

using namespace std;

vector<int> prefix_function(string s) {
    int n = (int)s.length();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int j = p[i - 1];
        while (j > 0 && s[j] != s[i])
            j = p[j - 1];
        if (s[j] == s[i])
            j++;
        p[i] = j;
    }
    return p;
}
int search(string word,string find){
    int cnt=0;
    string fnl=find+"#"+word;
    vector<int> v=prefix_function(fnl);
    for (int i=(int)find.length()+1; i<v.size(); i++)
        if (v[i]==find.length())
            cnt++;
    return cnt;
}
int main() {
    string s;   cin>>s;
    int n;  cin>>n;
    int l,r;
    while (n--) {
        cin>>l>>r;
        string find="";
        for (int i=l-1; i<r; i++)
            find+=s[i];
        cout<<search(s,find)<<endl;
    }
    return 0;
}
