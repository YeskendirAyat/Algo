//
//  main.cpp
//  Coriginal
//
//  Created by  Yeskendir Ayat on 21.11.2020.
//

#include <iostream>
#include <vector>
using namespace std;
vector<int> prefix_function(string s) {
    int n =(int) s.length();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int j = p[i - 1];
        while (j > 0 && s[j] != s[i])
            j = p[j - 1];
        if (s[j] == s[i])
            j++;
        p[i] = j;
    }
    return p;
}
int main() {
    int n;  cin>>n;
    vector<string> v(n);
    for (int i=0; i<n; i++) cin>>v[i];
    string ans="";
    string s=v[0];
    for(int i=0;i<s.size();i++)
        for(int j=i;j<s.size();j++) {
            int t;
            string word="";
            for(int k=i;k<=j;k++) word+=s[k];
            for(t=1;t<v.size();t++)
                if(v[t].find(word)==-1) break;
            if(t==v.size() && ans.size()<word.size())
                ans=word;
        }
    cout<<ans;
    return 0;
}
//3
//abacaba
//mycabarchive
//acabistrue

//3
//abcd
//ytubchtkd
//bcherudkd
//3
//bca
//dca
//gca
//3
//cba
//cga
//cfa
