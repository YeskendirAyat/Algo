//
//  main.cpp
//  A
//
//  Created by  Yeskendir Ayat on 21.11.2020.
//
#include<iostream>
#include<algorithm>
#include<vector>
#define ll long long
using namespace std;
vector<long long> pws(50000);
ll getHash(string s,int n) {
    ll result=0;
    for(int i=0;i<n;i++)
        result+=(s[i]-'a'+1)*pws[i];
    return result;
}
vector<ll> getHashes(string s,int n) {
    vector<ll> hash(n);
    for(ll i=0;i<n;i++) {
        hash[i]=(s[i]-'a'+1)*pws[i];
        if(i)
            hash[i]+=hash[i-1];
    }
    return hash;
}
int main() {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0)),cout.tie(0);
    pws[0]=1;
    for(ll i=1;i<50000;i++)
        pws[i]=pws[i-1]*31;
    string s;
    cin>>s;
    vector<ll> s_hashes=getHashes(s,(int)s.size());
    for (int i=0; i<s_hashes.size(); i++) {
        if () {
            <#statements#>
        }
    }
    return 0;
}
