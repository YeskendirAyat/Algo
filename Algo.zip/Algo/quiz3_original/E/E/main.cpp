//
//  main.cpp
//  E
//
//  Created by  Yeskendir Ayat on 21.11.2020.
//

#include <iostream>
#include <vector>

using namespace std;

vector<int> prefix_function(string s) {
    int n =(int) s.length();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int j = p[i - 1];
        while (j > 0 && s[j] != s[i])
            j = p[j - 1];
        if (s[j] == s[i])
            j++;
        p[i] = j;
    }
    return p;
}
void search(string s){
    vector<int> p = prefix_function(s);
    int n=p[p.size()-1];
    int cnt=0;
    for (int i=0; i<p.size(); i++)
        if (p[i]==n)
            cnt++;
    if (cnt>=2)
        for (int i=0; i<n; i++)
            cout<<s[i];
    else cout<<"Just a legend";
}
int main() {
    string s;
    cin >> s;
    search(s);
    return 0;
}
// fixfixfixfix
// fixfixfix
// 0 0 0 1 2 3 4 5 6
