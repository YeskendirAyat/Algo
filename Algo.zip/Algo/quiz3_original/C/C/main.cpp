//
//  main.cpp
//  C
//
//  Created by  Yeskendir Ayat on 21.11.2020.
//
#include <iostream>
#include <vector>

using namespace std;

vector<int> prefix_function(string s) {
    int n = (int)s.length();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int j = p[i - 1];
        while (j > 0 && s[j] != s[i])
            j = p[j - 1];
        if (s[j] == s[i])
            j++;
        p[i] = j;
    }
    return p;
}
bool search(string word,int n,string find){
    int cnt=0;
    string fnl=word+"#"+find;
    vector<int> v=prefix_function(fnl);
    for (int i=(int)word.length()+1; i<v.size(); i++)
        if (v[i]==word.length()){
            cnt++;
            if (cnt>=n) return true;
        }
    if (cnt>=n) return true;
    return false;
}
int main() {
    string word,find;   cin>>word;
    int n;  cin>>n;
    cin>>find;
    if (search(word,n,find)) {
        cout<<"YES";
    }
    else
        cout<<"NO";
    return 0;
}
//hello 2
//helloThomashelloArthurhelloJohnhello
//
