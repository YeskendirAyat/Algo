//
//  main.cpp
//  D
//
//  Created by  Yeskendir Ayat on 10/2/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include <iostream>
#include <algorithm>
using namespace std;
int main(int argc, const char * argv[]) {
    int n,k; cin>>n>>k;
    int arr[n];
    int a,b,c,d;
    int i=0;
    while (i<n) {
        cin>>a>>b>>c>>d;
        int m=max(a,b), k=max(c,d);
        int r=max(m,k);
        arr[i]=r;
        i++;
    }
    sort(arr,arr+n);
    cout<<arr[k-1];
    return 0;
}

// 10 7
// 5 1 7 8
// 1 3 5 4
// 5 8 8 10
// 7 1 8 5
// 9 1 10 5
// 4 4 7 5
// 1 6 7 7
// 5 7 9 10
// 4 8 5 9
// 4 2 5 3
