//
//  main.cpp
//  C & D
//
//  Created by  Yeskendir Ayat on 9/26/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
//
//#include <iostream>
//using namespace std;
//int main(int argc, const char * argv[]) {
//    int n,k;
//    cin>>n>>k;
//    int a[n];
//    for (int i=0; i<n; i++)
//        cin>>a[i];
//    int l1,r1,l2,r2;
//    while (k>0) {
//        int t=0;
//        cin>>l1>>r1>>l2>>r2;
//        for (int i=0; i<n; i++)
//            if ((a[i]>=l1 && a[i]<=r1) || (a[i]>=l2 && a[i]<=r2))
//                t++;
//        cout<<t<<"\n";
//        k--;
//    }
//    return 0;
//}

#include <iostream>
#include <iostream>
#include <vector>
using namespace std;
int upper_bound_bin_search(vector<int> &a, int x) {
    int l = 0;
    int r = a.size() - 1;
    while (l < r - 1){
        int m = (l + r) / 2;
        if (a[m] <= x)
            l = m;
        else
            r = m - 1;
    }
    if (a[r] == x)
        return r+1;
    else if (a[l] == x)
        return l+1;
    else
        return 0;
}
int lower_bound_bin_search(vector<int> &a, int x) {
    int l = 0;
    int r = a.size() -1;
    while (l != r){
        int m = (l + r) >>1;
        if (a[m] < x)
            l = m + 1;
        else
            r = m;
    }
    if (a[l] == x)
        return l+1;
    else
        return 0;
}
int main(int argc, const char * argv[]) {
    int n,k;
    cin>>n>>k;
    int a[n];
    for (int i=0; i<n; i++)
        cin>>a[i];
    int l1,r1,l2,r2;
    while (k>0) {
        int t=0;
        
        
        
//        cout<<t<<"\n";
        k--;
    }
    return 0;
}



//
//7 3
//21 1 2 3 5 8 13
//1 5 1 3
//2 1 1 1
//2 3 1 3
