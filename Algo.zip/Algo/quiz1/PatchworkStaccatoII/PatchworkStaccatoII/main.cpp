//
//  main.cpp
//  PatchworkStaccatoII
//
//  Created by  Yeskendir Ayat on 10/2/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    int n,m,l1,r1,r2,l2;  cin>>n>>m;
    int a[n];
    for (int i=0; i<n; i++) cin>>a[i];
    while (n>0) {
        cin>>l1>>r1>>l2>>r2;
        
        
        
        
        n--;
    }
    return 0;
}
