//
//  main.cpp
//  B
//
//  Created by  Yeskendir Ayat on 10/2/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include <iostream>
#include <deque>
#include <stack>
using namespace std;
int main(int argc, const char * argv[]) {
    deque<int> dq;
    int n;
    bool r=false;
    cin>>n;
    int s,num;
    while (n>0) {
        cin>>s;
        if (s==1) {
            cin>>num;
            if (r)
                dq.push_front(num);
            else
                dq.push_back(num);
        }
        if (s==2){
            if (r)
                r=false;
            else
                r=true;
        }
        n--;
    }
    if (r)
        while (!dq.empty()) {
            cout<<dq.back()<<" ";
            dq.pop_back();
        }
    else
        while (!dq.empty()) {
            cout<<dq.front()<<" ";
            dq.pop_front();
        }
    return 0;
}
