//
//  main.cpp
//  F
//
//  Created by  Yeskendir Ayat on 10/2/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include <iostream>
#include <vector>
using namespace std;
void check(int n){
    vector<int> v(n+1,0);
    v[0]=v[1]=1;
    for (int i=2; i*i<=n; i++)
        for (int j=i*i; j<=n; j+=i)
            v[j]++;
    int ans=-1;
    for (int i=1; i<v.size(); i++)
        if (v[i]==1)
            ans++;
    cout<<ans;
}
int main(int argc, const char * argv[]){
    int n;  cin>>n;
    check(n);
    return 0;
}
