#include <iostream>
using namespace std;
bool check(int n){
    int ans=0;
    for (int i=2; i<n; i++){
        if (n%i==0)
            ans++;
        if(n==i*i)
            ans++;
    }
    if (ans==2)
        return false;
    else
        return true;
}
int main(){
    int n,k=1;
    cin>>n;
    while (n>5) {
        if(check(n))
            k++;
        n--;
    }
    cout<<k;
    return 0;
}
