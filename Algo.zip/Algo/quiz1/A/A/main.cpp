//
//  main.cpp
//  A
//
//  Created by  Yeskendir Ayat on 10/2/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
// Jonathan the Poet

#include <iostream>
#include <vector>
using namespace std;
class Node{
    public:
    string data;
    Node *next,*prev;

    Node(string data){
        this->data= data;
        this->next = NULL;
        this->prev = NULL;
    }
};

class LinkedList{
    public:
    Node *tail,*front;
    int cnt=0;
    LinkedList(){
        tail=NULL;
        front=NULL;
    }
    void  push_front(string data){
        Node *node = new Node(data);
        if (front==NULL){
                front=node;
                tail=node;
        }else{
            front->prev=node;
            node->next=front;
            front=node;
        }
        cnt++;
    }

    void push_back(string data) {
        Node *node = new Node(data);
        if (tail == NULL) {
            tail = node;
            front = node;
        } else {
            tail->next = node;
            node->prev = tail;
            tail = node;
        }
        cnt++;
    }
    void pop_back() {
        if(tail!=NULL){
            tail=tail->prev;
            if (tail!=NULL)
                tail->next=NULL;
            else
                front=NULL;
        }
        cnt--;
    }
};
int main(){
    LinkedList *ll = new LinkedList();
    int n;  cin>>n;
    int k;  cin>>k;
    string s;
    for (int i = 0 ; i< n;i++){
        cin>>s;
        ll->push_front(s);
    }
    Node *p = ll->front;
    vector <string> second,first;
    for (int i = k  ; i< n;i++){
        second.push_back(p->data);
        p= p->next;
    }
    for (int i = 0 ; i<  k ;i++){
        first.push_back(ll->tail->data);
        ll->pop_back();
    }
    for (int i = second.size()-1;i>=0;i--)  cout<<second[i]<<" ";
    for (auto i : first)  cout<<i<< " ";
    cout<<endl;
    return 0;
}
