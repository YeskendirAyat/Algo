#include <iostream>
#include<string>
#include <sstream>
using namespace std;
class Node {
    public:
    int data;
    Node *next;
    Node(int data) {
        this->data = data;
        this->next = NULL;
    }
};
class LinkedList {
    public:
    Node *next;
    LinkedList() {
        next = NULL;
    }
    void push_front(int data) {
        Node *node = new Node(data);
        if (next == NULL) {
            next = node;
        } else {
            node->next = next;
            next = node;
        }
    }
    void print() {
        Node *node = next;
        while (node != NULL) {
            cout << node->data << " ";
            node = node->next;
        }
        cout << endl;
    }
    int plus(){
        Node *node = next;
        string res="";
        while (node != NULL) {
            res+=to_string(node->data);
            node=node->next;
        }
        stringstream geek(res);
        int x = 0;
        geek >> x;
        return x;
    }
};
int main() {
    LinkedList *ll = new LinkedList();
    LinkedList *ll2 = new LinkedList();
    int a;
    int cnt=3;
    while (cnt) {
        cin>>a;
        ll->push_front(a);
        cnt-=1;
    }
    cnt=3;
    while (cnt) {
        cin>>a;
        ll2->push_front(a);
        cnt-=1;
    }
    cout<<ll->plus()+ll2->plus();
    return 0;
}
