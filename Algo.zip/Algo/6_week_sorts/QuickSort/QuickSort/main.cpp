//
//  main.cpp
//  QuickSort
//
//  Created by  Yeskendir Ayat on 10/17/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
void swap(int* a, int* b){
    int t = *a; *a = *b; *b = t;
}
int partition (vector<int>&v, int low, int high){
    int pivot = v[high];
    int i = (low - 1);
    for (int j = low; j <= high- 1; j++){
        if (v[j] <= pivot){
            i++;
            swap(&v[i], &v[j]);
        }
    }
    swap(&v[i + 1], &v[high]);
    return (i + 1);
}
void quickSort(vector<int> &v, int low, int high){
    if (low < high){
        int pi = partition(v, low, high);
        for (int i=0; i<high+1; i++) {
            cout<<v[i]<<" ";
        }
        cout<<"\n";
        quickSort(v, low, pi - 1);
        quickSort(v, pi + 1, high);
    }
    return;
}
int main(){
    int k; cin>>k;
    vector<int> v(k);
    for (int i=0; i<k; i++) cin>>v[i];
    quickSort(v,0,(int)v.size()-1);
    cout<<"Sorted\n";
    for(auto i:v) cout<<i<<" ";
    return 0;
}
