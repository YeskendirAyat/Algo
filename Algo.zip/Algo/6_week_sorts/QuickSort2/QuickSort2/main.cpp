//
//  main.cpp
//  QuickSort2
//
//  Created by  Yeskendir Ayat on 10/17/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
int a[100000];
void quicksort(int l,int r){
    int i=l;
    int j=r;
    int p=a[(l+r)/2];
    while (i<j) {
        while (a[i]<p) i++;
        while (a[j]>p) j--;
        if (i<=j) {
            swap(a[i], a[j]);
            i++;
            j--;
        }
    }
    if (l < j)
        quicksort(l, j);
    if (i < r)
        quicksort(i, r);
}

int main(int argc, const char * argv[]) {
    int n;  cin>>n;
    for (int i=0; i<n; i++)
        a[i]=rand()%1000;
    quicksort(0,n-1);
    for (int i=0; i<n; i++)  cout<<a[i]<<" ";
    cout<<endl;
    return 0;
}
