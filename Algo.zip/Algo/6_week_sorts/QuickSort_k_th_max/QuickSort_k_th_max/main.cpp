//
//  main.cpp
//  QuickSort_k_th_max
//
//  Created by  Yeskendir Ayat on 10/17/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
using namespace std ;
int a[100];
void quicksort(int l,int r,int x){
    int i=l;
    int j=r;
    int p=a[(r+l)/2];
    while (i < j) {
        while (a[i] < p) i++;
        while (a[j] > p) j--;
        if (i <= j) {
            swap(a[i], a[j]);
            i++;
            j--;
        }
    }
    if (x<p) {
        quicksort(l, j,x);
    }
    else if(x>p){
        quicksort(i,r,x);
    }
    else return;
}
int main(int argc, const char * argv[]) {
    int n,x;  cin>>n>>x;
    for (int i=0; i<n; i++) cin>>a[i];
    quicksort(0, n-1, x);
    for (int i=0; i<n; i++) cout<<a[i]<<" ";
    return 0;
}
