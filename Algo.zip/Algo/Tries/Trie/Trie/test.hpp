//
//  test.hpp
//  Trie
//
//  Created by  Yeskendir Ayat on 14.11.2020.
//

#ifndef test_hpp
#define test_hpp

#include <stdio.h>

#endif /* test_hpp */
