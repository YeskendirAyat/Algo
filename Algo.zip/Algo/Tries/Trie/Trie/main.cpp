//
//  main.cpp
//  Trie
//
//  Created by  Yeskendir Ayat on 14.11.2020.
//

#include <iostream>
using namespace std;
int const N=10;
class Node{
public:
    Node *root;
    char data;
    Node *ch[N];
    int cnt;
    Node(char data){
        this->data=data;
        for (int i=0; i<N; i++)
            this->ch[i]=NULL;
        cnt=1;
    }
};
class Trie{
public:
    Node *root;
    Trie(){root=new Node(' ');}
    void insert(string s){
        Node *cur=root;
        for (int i=0; i<s.length(); i++) {
            if (cur->ch[s[i]-'a']!=NULL) {
                cur=cur->ch[s[i]-'a'];
                cur->cnt++;
            }
            else{
                Node *node=new Node(s[i]);
                cur->ch[s[i]-'a']=node;
                cur=node;}
        }
    }
    void search(Node *node,string s){
        if (s!="")
            cout<<s<<" cnt="<<node->cnt<<endl;
        for (int i=0; i<N; i++) {
            if (node->ch[i]!=NULL) {
                search(node->ch[i], s+node->ch[i]->data);
            }
        }
    }
    void searchLv(Node *node,string s){
        int ans=0;
        for (int i=0; i<N; i++)
            if (node->ch[i]!=NULL)
                ans++;
        if (ans<1)
            cout<<s<<" cnt="<<node->cnt<<endl;
        for (int i=0; i<N; i++)
            if (node->ch[i]!=NULL)
                searchLv(node->ch[i], s+node->ch[i]->data);
    }
};
int main(int argc, const char * argv[]) {
    Trie *tr=new Trie();
    int n;  cin>>n;
    string s;
    for (int i=0; i<n; i++) {
        cin>>s;
        tr->insert(s);
    }
    tr->searchLv(tr->root,"");
    
    
    return 0;
}
