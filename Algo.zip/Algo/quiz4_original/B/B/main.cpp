//
//  main.cpp
//  B
//
//  Created by  Yeskendir Ayat on 05.12.2020.
//
#include<iostream>
using namespace std;
int n,m,x,y,z;
int main() {
    cin>>n>>m;
    int a[n][n];
    for (int i=0; i<n; i++)
        for (int j=0; j<n; j++)
            cin>>a[i][j];
    while (m--) {
        cin>>x>>y>>z; x--;y--;z--;
        if (a[x][y]==1 && a[x][z]==1 && a[y][z]==1)
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;
    }
    return 0;
}
//4 4 1 1 0 1 1 1 1 1 0 1 1 0 1 1 0 1 1 2 4 2 3 4 1 2 2 3 3 4
