//
//  main.cpp
//  C
//
//  Created by  Yeskendir Ayat on 05.12.2020.
//
#include<iostream>
#include<queue>
#include <algorithm>
#include <vector>
using namespace std;
bool used[1000][1000];
int d[1000][1000];
queue<pair<int,int>>q;
int g[1000][1000];
int dx[]={1,-1,0,0};
int dy[]={0,0,1,-1};
int n,m,corx,cory;
void bfs(){
    while (!q.empty()) {
        for(int i=0;i<4;i++){
            int xx = q.front().first+dx[i],yy=q.front().second+dy[i];
            if((xx<n && xx>=0 && yy<m && yy>=0) and g[xx][yy]==1 and !used[xx][yy]){
                used[xx][yy]=true;
                corx=xx;cory=yy;
                g[xx][yy]=2;
                d[xx][yy]=d[q.front().first][q.front().second]+1;
                q.push({xx,yy});
            }
        }
        q.pop();
    }
}
int main() {
    cin>>n>>m;
    for (int i=0; i<n; i++)
        for (int j=0; j<m; j++) {
            cin>>g[i][j];
            if (g[i][j]==2) q.push({i,j});
        }
    bfs();
    for (int i=0; i<n; i++)
        for (int j=0; j<m; j++)
            if (!used[i][j] and g[i][j]==1) {
                cout<<-1;
                exit(0);
            }
    cout<<d[corx][cory];
    return 0;
}
