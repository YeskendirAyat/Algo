//
//  main.cpp
//  A
//
//  Created by  Yeskendir Ayat on 05.12.2020.
//
// D
#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
#include <cmath>
#include <stack>

using namespace std;
int n,m,x,y;
vector<int> g[100000];
vector<int> v;
stack<int> s;
int used[100000];
void dfs(int k) {
    used[k] = 1;
    for (int i = 0; i < g[k].size(); i++) {
        y = g[k][i];
        if (!used[y])
            dfs(y);
    }
    s.push(k);
}
int main(){
    cin>>n>>m;
    for (int i=0;i<m; i++) {
        cin>>x>>y;x--;y--;
        g[x].push_back(y);
    }

    for (int i=0; i<n; i++) {
        if (used[i]==0) {
            dfs(i);
        }
    }
//    reverse(v.begin(), v.end());
//
//    for (int i=0; i<v.size(); i++) {
//        cout<<v[i]+1<<" ";
//    }
    while (!s.empty())
    {
        cout<<s.top() + 1<<" ";
        s.pop();
    }
    return 0;
}
