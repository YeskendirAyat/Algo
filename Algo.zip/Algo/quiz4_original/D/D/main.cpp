//
//  main.cpp
//  D
//
//  Created by  Yeskendir Ayat on 05.12.2020.
//

#include<iostream>
#include<vector>
#include<queue>
using namespace std;
vector<int> g[100000];
int used[100000];
vector<int> res[100000];
int n,m,x,y;
void bfs(int x,int ord) {
    queue<int> q;
    res[ord].push_back(x);
    q.push(x);
    used[x]=1;
    while(!q.empty()) {
        int v=q.front();
        for(int i=0;i<g[v].size();i++){
            y=g[v][i];
            if(used[y]==0) {
                used[y]=1;
                res[ord].push_back(y);
                q.push(y);
            }
        }
        q.pop();
    }
}
int main() {
    cin>>n>>m;
    for(int i=0;i<m;i++) {
        cin>>x>>y;
        x--;
        y--;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    int cnt=0;
    for(int i=0;i<n;i++)
        if(used[i]==0) {
            bfs(i,cnt);
            cnt++;
        }
    int min=100000;
    for(int i=0;i<cnt;i++)
        if (min>res[i].size())
            min=(int)res[i].size();
    cout<<min;
    return 0;
}
//5 4 1 2 2 3 3 1 4 5
//4 3 1 2 2 3 3 4
