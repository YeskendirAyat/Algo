//
//  main.cpp
//  B2
//
//  Created by  Yeskendir Ayat on 05.12.2020.
//
#include<iostream>
using namespace std;
int n,m,x,y,z;
int a[1000][1000];
int main() {
    cin>>n>>m;
    for (int i=0; i<n; i++)
        for (int j=0; j<m; j++)
            cin>>a[i][j];
    for (int i=0; i<m; i++) {
        cin>>x>>y>>z;
        x--;y--;z--;
        if (a[x][y] && a[x][z] && a[y][z])
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;
    }
    return 0;
}
//4 4 1 1 0 1 1 1 1 1 0 1 1 0 1 1 0 1 1 2 4 2 3 4 1 2 2 3 3 4
