//
//  main.cpp
//  B
//
//  Created by  Yeskendir Ayat on 10/23/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
using namespace std;
int main(int argc, const char * argv[]) {
    int n,m; cin>>n>>m;
    int a[n];
    int ans=0;
    for (int i=0; i<n; i++) cin>>a[i];
    for (int i=0; i<n-1; i++){
        if (ans>=m) {
            cout<<i;
            exit(0);
        }
        ans+=a[i]+(2*a[i+1]);
    }
    cout<<-1;
    return 0;
}
