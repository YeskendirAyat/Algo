//
//  main.cpp
//  J
//
//  Created by  Yeskendir Ayat on 10/23/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

//
//  main.cpp
//  G
//
//  Created by  Yeskendir Ayat on 10/23/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <map>
#include <vector>
using namespace std;
class Node{
public:
    int data;
    Node *left,*right;
    Node(int data){
        this->data=data;
        right=NULL;
        left=NULL;
    }
};
class BST{
public:
    Node *root;
    BST(){root=NULL;}
    Node *insert(Node *node,int data){
        if (node==NULL) {
            node=new Node(data);
            return node;}
        if (data<=node->data)
            node->left=insert(node->left, data);
        else
            node->right=insert(node->right, data);
        return node;
    }
    bool check(Node *node,int data){
        if (node==NULL) {
            return true;
        }
        while (node!=NULL) {
            if (node->data==data) {
                return false;
            }
            if (data<node->data)
                node=node->left;
            else if(data>node->data)
                node=node->right;
        }
        return true;
    }
    int size(Node *node){
        if (node==NULL)
            return 0;
        else
            return size(node->left)+size(node->right)+1;
    }
    void inOrder(Node *node){
        if (node==NULL) {
            return;
        }
        inOrder(node->left);
        cout<<node->data<<" ";
        inOrder(node->right);
    }
    Node *findMin(Node *node) {
        while (node->left != NULL)
            node = node->left;
        return node;
    }
    bool checkAns(Node *node){
        if (node==NULL)
            return true;
        int l=Depth(node->left);
        int r=Depth(node->right);
        if(abs(r-l)<=1 && checkAns(node->left) && checkAns(node->right)) return true;
        else return false;
    }
    int Depth(Node *node){
        if (node == NULL)
            return 0;
        else{
            int lDepth = Depth(node->left);
            int rDepth = Depth(node->right);
            return lDepth>rDepth ? lDepth+1 : rDepth+1;
        }
    }
    void countDepth(Node *node,int t){
        if (node==NULL) {
            return;
        }
        countDepth(node->left,t);
        if (node->data==t){
            cout<<Depth(node)<<endl;
        }
        countDepth(node->right,t);
    }
    Node *findMax(Node *node) {
        while (node->right != NULL)
            node = node->right;
        return node;
    }
    Node *deleteNode(Node *node, int data) {
        if (node == NULL)
            return NULL;
        if (data < node->data)
            node->left = deleteNode(node->left, data);
        else if (data > node->data)
            node->right = deleteNode(node->right, data);
        else {
            if (node->left == NULL && node->right == NULL)
                return NULL;
            else if (node->left == NULL)
                node = node->right;
            else if (node->right == NULL)
                node = node->left;
            else {
                Node *tmp = findMax(node->left);
                node->data = tmp->data;
                node->left = deleteNode(node->left, tmp->data);
            }
        }
        return node;
    }
};

int main(int argc, const char * argv[]) {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0)),cout.tie(0);
    BST *bst=new BST();
    int n,t;
    cin>>n;
    while(n--) {
        cin>>t;
        bst->root=bst->insert(bst->root, t);
    }
    int x;  cin>>x;
//    cout<<bst->Depth(bst->root);
//    bst->countDepth(bst->root,x);
    bst->countDepth(bst->root, x);
    return 0;
}
//7
//4 2 6 1 3 5 7
