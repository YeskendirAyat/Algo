////
////  main.cpp
////  K
////
////  Created by  Yeskendir Ayat on 10/24/20.
////  Copyright © 2020 Macbook. All rights reserved.
////
//
//#include <iostream>
//#include <vector>
//#include <map>
//using namespace std;
//const int N= (int)1e5+7;
//int a[N];
//void quicksort(int l, int r) {
//    int i = l;
//    int j = r;
//    int p = a[(l + r) / 2];
//
//    while (i < j) {
//        while (a[i] < p) i++;
//        while (a[j] > p) j--;
//        if (i <= j) {
//            swap(a[i], a[j]);
//            i++;
//            j--;
//        }
//    }
//    if (l < j)
//        quicksort(l, j);
//    if (i < r)
//        quicksort(i, r);
//}
//
//int main(int argc, const char * argv[]) {
//    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0)),cout.tie(0);
//    int n,m;  cin>>n>>m;
//    int b[m];
//    for (int i=0; i<n; i++) cin>>a[i];
//    for (int i=0; i<m; i++) cin>>b[i];
//    quicksort(0,n-1);
//    for (int i=0; i<m; i++)
//        for (int j=0; j<n; j++)
//            if (b[i]==a[j]) {
//                cout<<a[j]<<" ";
//                a[j]=0;
//            }
//    for (int i=0; i<n; i++){
//        if (a[i]!=0) {
//            cout<<a[i]<<" ";
//        }
//    }
//
//    return 0;
//}
//
//
//
////11 6
////2 9 2 19 3 1 3 2 4 6 7
////2 1 4 3 9 6


#include<iostream>
#include <vector>
using namespace std;

class MaxHeap {
public:
    vector<int> a;
    int parent(int i) {return (i - 1) / 2;}

    int left(int i) {
        return 2 * i + 1;
    }

    int right( int i) {
        return 2 * i + 2;
    }

    void insert(int k) {
        a.push_back(k);
    }
    void siftUp(int i){
        if (i > (int)a.size())
            return;
        if(i>0 && a[i] > a[parent(i)]){
            swap(a[parent(i)],(a[i]));
            siftUp(parent(i));
        }
    }

    void siftDown(int i){
        if (i>(int)a.size())
            return;
        int j = i;
        if (left(i) <(int) a.size() && a[left(i)] > a[i])
            j = left(i);
        if (right(i) <(int) a.size() && a[right(i)] > a[j])
            j = right(i);
        if(j!=i){
            swap(a[i],a[j]);
            siftDown(j);
        }
    }
    
    void print() {
        if ((int)a.size()<=1) {
            for (int i = 0; i <(int) a.size(); i++)
                cout << a[i] << " ";
        }
        else
            for (int i = 0; i <(int) a.size(); i++)
                cout << a[i] << " ";
                cout << endl;
    }


    int get_max(){
        return a[0];
    }

    int top(){return a[0];}

    int extract_max(){
        int max=get_max();
        a[0]=a.back();
        a.pop_back();
        if (!a.empty())
            siftDown(0);
        return max;
    }
};

int main() {
    MaxHeap *max_heap = new MaxHeap();
    int c;
    cin >> c;
    int z[c];
    vector<int> barca;
    for (int i=0;i<c;i++) {
        cin >>z[i];
        max_heap->insert(z[i]);
        barca.push_back(z[i]);
    }
    for(int i=(int)max_heap->a.size()/2-1;i>=0;i--)
        max_heap->siftDown(i);
    while(c--){
        max_heap->extract_max();
        max_heap->print();
    }
    sort(barca.rbegin(),barca.rend());
    for(int i=0;i<c;i++){
        cout << barca.back() <<" ";
        barca.pop_back();
    }
    return 0;
}
