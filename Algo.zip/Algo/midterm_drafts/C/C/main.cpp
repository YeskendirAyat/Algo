//
//  main.cpp
//  C
//
//  Created by  Yeskendir Ayat on 10/23/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include <iostream>
#include <vector>
#include <cmath>
#include <sstream>
using namespace std;
vector<string> a;
void quicksort(int l,int r){
    int i=l;
    int j=r;
    int p=(int)a[ceil(l+r)/2].length();
    while (i<j) {
        while (a[i].length()<p) i++;
        while (a[j].length()>p) j--;
        if (i<=j) {
            if(a[i].length()>a[j].length())
                swap(a[i], a[j]);
            i++;
            j--;
        }
    }
    if (l < j)
        quicksort(l, j);
    if (i < r)
        quicksort(i, r);
}
void sort(){
    for (int i=1 ;i<a.size(); i++){
        string temp = a[i];
        int j = i - 1;
        while (j >= 0 && temp.length() < a[j].length()){
            if (temp.length()== a[j].length())
                continue;
            else
                a[j+1] = a[j];
            j--;
        }
        a[j+1] = temp;
    }
}
void sort1(){
for (int i=0 ;i<a.size(); i++){
    for (int j=i+1;j<a.size(); j++)
        if (a[i].length()>a[j].length())
            swap(a[i],a[j]);
    }
}
int main(){
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0)),cout.tie(0);
    int n;  cin>>n;
    while (n--) {
        string s="",t="";
        cin>>s;
        t+=s;
        getline(cin,s);
        s=t+s;
        t="";
        for (int i=0; i<s.size(); i++) {
            if (s[i]==' ') {
                a.push_back(t);
                t="";
            }
            else
                t+=s[i];
        }
        a.push_back(t);
        quicksort(0,(int)a.size()-1);

//        sort1();
        for(int i=0;i<a.size();i++)
            cout<<a[i]<<" ";
        cout<<endl;
        a.clear();
    }
    return 0;
}
//e j ab cd df asd ljffg
//ab cd e j asd ljffg df

//3
//ab cd e j asd ljffgdf
//a a b b c c
//xy yx zxy zx xzy xxx


//4
//aabc ddfd fbbe f baaad
//fddf badcf aedbe cdb ae bbd
//ada bc eaced dadab b aabc fbee
//bedaf edde fcaa adbf beec

//===
//f aabc ddfd fbbe baaad
//ae cdb bbd fddf badcf aedbe
//b bc ada aabc fbee eaced dadab
//edde fcaa adbf beec bedaf
