//
//  main.cpp
//  B2
//
//  Created by  Yeskendir Ayat on 10/23/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
#include <cmath>
#include <set>
#define pb push_back
#define In insert
#define mp make_pair
#define sz(v) (int)v.size()
#define be(v) v.begin(),v.end()
#define f first
#define s second
#define ffor(i,a,b) for (int i = (a); i < (b); i++)
#define ffore(i,a,b) for (int i = (a-1); i >= (b); i--)
 
using namespace std;
using ll = long long;
using dd = double;
typedef pair<int, int> II;
typedef pair<II, int> III;
typedef vector<int> vI;
typedef vector<pair<int,int>> vII;
typedef set<int> sI;
const int N= (int)1e5+7;
int a[N];
vI foo;
void merge_sort(int *a,int l, int r){
    if (l<r){
        int m = (l+r)/2;
        foo.pb(a[m]);
        merge_sort(a,l,m);
        merge_sort(a,m+1,r);
    }
}

void TaoCode(){
    int t;  cin>>t;
    int n=pow(2,t)-1;
    ffor(i,0,n) cin>>a[i];
    sort(a,a+n);
    merge_sort(a,0,n-1);
    ffor(i,0,n-1) cout<<foo[i]<<" ";
    cout<<a[n-1];
}
 
int main() {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0)),cout.tie(0);
    TaoCode();
    return 0;
}
