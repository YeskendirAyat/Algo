//
//  main.cpp
//  topview
//
//  Created by  Yeskendir Ayat on 10/24/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
vector<int> mv;
class Node{
public:
    int data;
    Node *left,*right;
    Node(int data){
        this->data=data;
        right=NULL;
        left=NULL;
    }
};
class BST{
public:
    Node *root;
    BST(){root=NULL;}
    Node *insert(Node *node,int data){
        if (node==NULL) {
            node=new Node(data);
            return node;}
        if (data<=node->data)
            node->left=insert(node->left, data);
        else
            node->right=insert(node->right, data);
        return node;
    }
    bool check(Node *node,int data){
        if (node==NULL) {
            return true;
        }
        while (node!=NULL) {
            if (node->data==data) {
                return false;
            }
            if (data<node->data)
                node=node->left;
            else if(data>node->data)
                node=node->right;
        }
        return true;
    }

    void inOrder(Node *node){
        if (node==NULL) {
            return;
        }
        else{
            inOrder(node->left);
            cout<<node->data<<" ";
            inOrder(node->right);
        }
    }
    int Depth(Node *node){
        if (node == NULL)
            return 0;
        else{
            int lDepth = Depth(node->left);
            int rDepth = Depth(node->right);
            return lDepth>rDepth ? lDepth+1 : rDepth+1;
        }
    }
    void left(Node *node){
        while (node!=NULL) {
            mv.push_back(node->data);
            node=node->left;
        }
    }
    void right(Node *node){
        while (node!=NULL) {
            mv.push_back(node->data);
            node=node->right;
        }
    }
    Node *findMin(Node *node){
        while (node->left!=NULL) { node=node->left; }
        return node;
    }
    Node *findMax(Node *node){
        while (node->right!=NULL) { node=node->right; }
        return node;
    }
    Node *deleteNode(Node *node,int data){
        if (node==NULL)
            return NULL;
        if (data<node->data)
            node->left=deleteNode(node->left, data);
        else if(data>node->data)
            node->right=deleteNode(node->right, data);
        else{
            if(node->right==NULL && node->left==NULL)
                node=NULL;
            else if(node->left==NULL && node->right!=NULL)
                node=node->right;
            else if(node->left!=NULL && node->right==NULL)
                node=node->left;
            else{
                Node *tmp=findMax(node->right);
                node->data=tmp->data;
                node->right=deleteNode(node->right, tmp->data);
            }
        }
        return node;
    }
};
int main(int argc, const char * argv[]) {
    BST *bst=new BST();
    int n,k;  cin>>n;
    while (n--) {
        cin>>k;
        bst->root=bst->insert(bst->root,k);
    }
    bst->left(bst->root->left);
    sort(mv.begin(),mv.end());
    mv.push_back(bst->root->data);
    bst->right(bst->root->right);
    for(auto i:mv)  cout<<i<<" ";
    return 0;
}
