//
//  main.cpp
//  bigSort
//
//  Created by  Yeskendir Ayat on 10/24/20.
//  Copyright © 2020 Macbook. All rights reserved.
//
#include <iostream>
#include <vector>
using namespace std;

int a[1000];
void quicksort(int l, int r) {
    int i = l;
    int j = r;
    int p = a[(l + r) / 2];
    while (i < j) {
        while (a[i] < p) i++;
        while (a[j] > p) j--;
        if (i <= j) {
            swap(a[i], a[j]);
            i++;
            j--;
        }
    }
    for (int k=l; k<r; k++)
        cout<<a[k]<<" ";
    cout<<endl;

    if (l < j)
        quicksort(l, j);
    if (i < r)
        quicksort(i, r);

}
int main() {
    static_cast<void>(ios::sync_with_stdio(false)),static_cast<void>(cin.tie(0)),cout.tie(0);
    int n;  cin>>n;
    for (int i=0; i<n; i++) {
        cin>>a[i];
    }
    quicksort(0, n-1);
    cout<<endl;
    for(int i=0; i<n; i++)
        cout<<a[i]<<" ";
    return 0;
}
