//
//  main.cpp
//  A
//
//  Created by  Yeskendir Ayat on 10/23/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
vector<int> mv;
class Node{
public:
    int data;
    Node *left,*right;
    Node(int data){
        this->data=data;
        right=NULL;
        left=NULL;
    }
};
class BST{
public:
    Node *root;
    BST(){root=NULL;}
    Node *insert(Node *node,int data){
        if (node==NULL) {
            node=new Node(data);
            return node;}
        if (data<=node->data)
            node->left=insert(node->left, data);
        else
            node->right=insert(node->right, data);
        return node;
    }
    bool check(Node *node,int data){
        if (node==NULL) {
            return true;
        }
        while (node!=NULL) {
            if (node->data==data) {
                return false;
            }
            if (data<node->data)
                node=node->left;
            else if(data>node->data)
                node=node->right;
        }
        return true;
    }
    int size(Node *node){
        if (node==NULL)
            return 0;
        else
            return size(node->left)+size(node->right)+1;
    }
    void inOrder(Node *node){
        if (node==NULL) {
            return;
        }
        cout<<node->data<<" ";
        inOrder(node->left);
        inOrder(node->right);

    }
    bool checkAns(Node *node){
        if (node==NULL)
            return true;
        int l=Depth(node->left);
        int r=Depth(node->right);
        if(abs(r-l)<=1 && checkAns(node->left) && checkAns(node->right)) return true;
        else return false;
    }
    int Depth(Node *node){
        if (node == NULL)
            return 0;
        else{
            int lDepth = Depth(node->left);
            int rDepth = Depth(node->right);
            mv.push_back(max(lDepth,rDepth));
            return lDepth>rDepth ? lDepth+1 : rDepth+1;
        }
    }


};
int main(int argc, const char * argv[]) {
    BST *bst=new BST();
    int k;  cin>>k;
    int n=pow(2,k)-1;
    int a[n];
    for(int i=0;i<n;i++) cin>>a[i];
    sort(a,a+n);
    int t=ceil(n/2);
    bst->root=bst->insert(bst->root,a[t]);
    for (int i=0; i<n; i++) {
        if (bst->check(bst->root, a[i])) {
            bst->root=bst->insert(bst->root,a[i]);
        }
    }
    bst->inOrder(bst->root);
    return 0;
}


//
//#include<iostream>
//using namespace std;
//#define ll long long
//#define vi vector<int>
//#define vll vector<ll>
//#define vd vector<double>
//#define pb push_back
//#define ends " "
//#define For(i,n) for(int i=0;i<n;i++)
//#define FoR(i,n,x) for(int i=x;i<n;i++)
//template<typename T>
//void enter(vector<T>& a, int n){
//    For(i,n) cin >> a[i];
//}
//template<typename T>
//void print(vector<T>& a){
//    For(i,a.size()) cout<<a[i]<<ends;
//    cout << endl;
//}
//int main(){
//
//    int n,q;
//    cin >> n >> q;
//    int a[n+1], p[n+1];
//    a[0] = 0;
//    p[0] = 1;
//    for(int i = 1;i <=n ;i++){
//        cin >> a[i];
//        if(a[i-1] < a[i]){
//            p[i] = p[i-1];
//        }
//        else {
//            p[i] = (p[i-1]+1);
//        }
//    }
//    For(i,q){
//        int l,r;
//        cin >> l >> r;
//        if(p[r] == p[l]) cout << 1 << endl;
//        else cout << p[r] << endl;
//    }
//    return 0;
//}
