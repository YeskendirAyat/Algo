//
//  main.cpp
//  CodeForce_C
//
//  Created by  Yeskendir Ayat on 9/26/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
#include <queue>
using namespace std;
int main(){
    int n;
    cin>>n;
    string s;
    cin>>s;
    queue<int> q1;
    queue<int> q2;
    for (int i=0; i<n; i++) {
        if(s[i]=='D')
            q1.push(i+1);
        else
            q2.push(i+1);
    }
    if (q1.empty())
        cout<<'R'<<endl;
    else if(q2.empty())
        cout<<'D'<<endl;
    else{
        while (!q1.empty() && !q2.empty()) {
            if(q1.front()>q2.front())
                q2.push(n);
            else
                q1.push(n);
            q1.pop();
            q2.pop();
            n++;
        }
        if (q1.empty())
            cout<<'R'<<endl;
        else if(q2.empty())
            cout<<'D'<<endl;
    }
    return 0;
}
