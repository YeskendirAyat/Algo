#include <iostream>
#include <vector>
#include <math.h>
using namespace std;
void sieve_of_eratosthenes(int n){
    vector<int> v(n+1,true);
    vector<int> v2;
    v[0]=false;
    v[1]=false;
    for (int i=2; i<=sqrt(n); i++) {
        if (v[i]) {
            for (int j=i*i; j<n; j+=i) {
                v[j]=false;
            }
        }
    }
    for (int i=0; i<n; i++) {
        if (v[i]){
            v2.push_back(i);
        }
    }
    for (int i=0; i<v2.size(); i++) {
        for (int k=i; k<v2.size(); k++) {
            if((v2[i]+v2[k])==n){
                cout<<v2[i]<<" "<<v2[k]<<endl;
                exit(0);
            }
        }
    }
}
int main() {
    int n;
    cin>>n;
    sieve_of_eratosthenes(n);
    return 0;
}
