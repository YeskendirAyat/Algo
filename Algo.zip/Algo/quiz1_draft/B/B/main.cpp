#include <iostream>
using namespace std;
class Node{
    public:
    int data;
    Node *next,*prev;

    Node (int data){
        this->data=data;
        this->next=NULL;
        this->prev=NULL;
    }
};

class LinkedList{
    public:
    Node *tail,*front;
    int cnt=0;
    LinkedList(){
        tail=NULL;
        front=NULL;

    }

    void push_front(int data){
        Node *node = new Node(data);
        if(front==NULL){
            front=node;
            tail=node;
        }
        else{
            front->prev=node;
            node->next=front;
            front=node;
        }
        cnt++;
    }
    void push_back(int data){
        Node *node = new Node(data);
        if(front==NULL){
            front=node;
            tail=node;
        }
        else{
            tail->next=node;
            node->prev=front;
            tail=node;
        }
        cnt++;
    }
    void pop_back() {
        if(tail!=NULL){
            tail=tail->prev;
            if (tail!=NULL)
                tail->next=NULL;
            else
                front=NULL;
        }
        cnt--;
    }

    void pop_front() {
        if(front!=NULL){
            front=front->next;
            if (front!=NULL)
                front->prev=NULL;
            else
                tail=NULL;
        }
        cnt--;
    }
    Node* find_node (int data){
        Node *node = front;
        while(node!=NULL){
            if(node->data == data ){
                return node;
            }
            node=node->next;
        }
        return NULL;
    }
};

int main(){
    LinkedList *ll = new LinkedList();
    int n;
    cin>>n;
    string s;
    int cnt=0;
    for (int i = 0 ; i< n;i++){
        cin>>s;
        if(s=="insertFirst"){
            cnt++;
            int x;
            cin>>x;
            ll->push_front(x);
        }
        else if (s=="insertLast"){
            cnt++;
            int x;
            cin>>x;
            ll->push_back(x);
        }
        else if (s=="cnt"){
            int x;  cin>>x;
            int cnt=0;
            Node *p = ll->front;
            for (int j = 0 ; j< ll->cnt;j++){
                if(p->data == x){
                    cnt++;
                }
                p=p->next;
            }
            cout<<cnt<<"\n";
        }
        else if (s=="getNth"){
            int x;  cin>>x;
            bool ok = true;
            if((x>= ll->cnt) and (x<0)){
                ok=false;
            }
            Node *p = ll->front;
            if (ok){
                for (int j = 0 ; j< ll->cnt;j++){
                    if(j==x){
                        
                        cout<<p->data<<"\n";
                    }
                    p=p->next;
                }
            }
            else{
                cout<<-1<<'\n';
            }
        }

    }
    for (int i = 0 ; i<cnt;i++){
        cout<<ll->front->data<< " ";
        ll->pop_front();
    }
    return 0;
}
