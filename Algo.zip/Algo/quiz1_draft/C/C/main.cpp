#include <iostream>
#include <vector>
using namespace std;
class Node {
    public:
    int data;
    Node *next;
    Node(int data) {
        this->data = data;
        this->next = NULL;
    }
};
class Stack {
    public:
    Node *top;
    vector<int> max;
    Stack() {
        top = NULL;
    }
    void add(int data) {
        Node *node = new Node(data);
        node->next = top;
        max.push_back(data);
        sort(max.begin(), max.end());
        top = node;
    }
    void del() {
        max.pop_back();
        top = top->next;
    }
    void front(){
        cout<<top->data<<"\n";
    }
    int getmax(){
        return *max_element(max.begin(), max.end()); ;
    }
};
int main() {
    Stack *st = new Stack();
    int c;
    cin>>c;
    while (c>0) {
        int n;
        string s;
        cin>>s;
        if (s=="q") {
            break;
        }
        else if(s=="add"){
            cin>>n;
            st->add(n);
            cout<<endl;
        }
        else if(s=="delete"){
            st->del();
        }
        else if(s=="getcur")
            st->front();
        else if(s=="getmax")
            cout<<st->getmax()<<endl;
        c--;
    }
    return 0;
}
