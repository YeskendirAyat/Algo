#include <iostream>
#include <vector>
#include <math.h>
using namespace std;
void sieve_of_eratosthenes(int n){
    vector<int> v(100000,true);
    vector<int> v2;
    v[0]=false;
    v[1]=false;
    for (int i=2; i*i<=v.size(); i++) {
        if (v[i]){
            for (int j=i*i; j<=v.size(); j+=i)
                v[j]=false;
        }
    }
    int a[v.size()];
    int k = 0;
    for (int i=2; i<=v.size(); i++){
        if (v[i])
            a[k++] = i;
    }
    for (int i=0; i<100000; i++){
       if (v[i+1])
           v2.push_back(a[i]);
    }
    cout<<v2[n-1]<<endl;
}
int main() {
    int n;
    cin>>n;
    sieve_of_eratosthenes(n);
    return 0;
}
