#include <iostream>
using namespace std;
class Node {
    public:
    int data;
    Node *next;
    Node(int data) {
        this->data = data;
        this->next = NULL;
    }
};
class LinkedList {
    public:
    Node *next;
    LinkedList() {
        next = NULL;
    }
    void push_front(int data) {
        Node *node = new Node(data);
        if (next == NULL) {
            next = node;
        } else {
            node->next = next;
            next = node;
        }
    }
    void print() {
        Node *node = next;
        while (node != NULL) {
            cout << node->data << " ";
            node = node->next;
        }
        cout << endl;
    }
};
int main() {
    LinkedList *ll = new LinkedList();
    int a;
    while (cin>>a) {
        ll->push_front(a);
    }
    ll->print();
    return 0;
}
