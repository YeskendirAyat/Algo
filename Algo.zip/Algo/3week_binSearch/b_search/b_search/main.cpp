#include <iostream>
#include <vector>
using namespace std;
void b_search(vector<int> &v,int x) {
    int l=0,m;
    int r=v.size()-1;
    while(l<=r) {
        m=(l+r)/2;
        if(v[m]==x){
            cout<<m+1;
            break;
        }
        else if(v[m]>x)
            r=m-1;
        else
            l=m+1;
    }
}
int main(int argc, const char * argv[]) {
    int n,x;
    cin>>n;
    vector<int> v(n);
    for (int i=0; i<n; i++) {
        cin>>v[i];
    }
    cin>>x;
    b_search(v, x);
    return 0;
}
