//
//  main.cpp
//  myBST
//
//  Created by  Yeskendir Ayat on 10/9/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

#include <iostream>
using namespace std;
class Node{
public:
    int data;
    Node *left,*right;
    Node(int data){
        this->data=data;
        right=NULL;
        left=NULL;
    }
};
class BST{
public:
    Node *root;
    BST(){root=NULL;}
    Node *insert(Node *node,int data){
        if (node==NULL) {
            node=new Node(data);
            return node;}
        if (data<=node->data)
            node->left=insert(node->left, data);
        else
            node->right=insert(node->right, data);
        return node;
    }
    void inOrder(Node *node){
        if (node==NULL) {
            return;
        }
        inOrder(node->left);
        cout<<node->data<<" ";
        inOrder(node->right);
    }
    void getSize(Node *node){
        if (node==NULL) {
            return;
        }
        inOrder(node->left);
        cout<<node->data<<" ";
        inOrder(node->right);
        
    }
    int Depth(Node *node){
        if (node == NULL)
            return 0;
        else{
            /* compute the depth of each subtree */
            int lDepth = Depth(node->left);
            int rDepth = Depth(node->right);
            /* use the larger one */
            if (lDepth > rDepth)
                return(lDepth + 1);
            else return(rDepth + 1);
        }
    }
    Node *findMin(Node *node){
        while (node->left!=NULL) { node=node->left; }
        return node;
    }
    Node *findMax(Node *node){
        while (node->right!=NULL) { node=node->right; }
        return node;
    }
    Node *deleteNode(Node *node,int data){
        if (node==NULL)
            return NULL;
        if (data<node->data)
            node->left=deleteNode(node->left, data);
        else if(data>node->data)
            node->right=deleteNode(node->right, data);
        else{
            if(node->right==NULL && node->left==NULL)
                node=NULL;
            else if(node->left==NULL && node->right!=NULL)
                node=node->right;
            else if(node->left!=NULL && node->right==NULL)
                node=node->left;
            else{
                Node *tmp=findMax(node->right);
                node->data=tmp->data;
                node->right=deleteNode(node->right, tmp->data);
            }
        }
        return node;
    }
};
int main(int argc, const char * argv[]) {
    BST *bst=new BST();
    bst->root=bst->insert(bst->root, 7);
    bst->root=bst->insert(bst->root, 3);
    bst->root=bst->insert(bst->root, 2);
    bst->root=bst->insert(bst->root, 1);
    bst->root=bst->insert(bst->root, 9);
    bst->root=bst->insert(bst->root, 5);
    bst->root=bst->insert(bst->root, 4);
    bst->root=bst->insert(bst->root, 6);
    bst->root=bst->insert(bst->root, 8);
//    cout<<bst->root->left->left->data;
//    bst->inOrder(bst->root);
    cout<<bst->root->data<<"\n";
    cout<<bst->Depth(bst->root);
    
//    cout<<bst->findMax(bst->root)->data<<"\n";
    return 0;
}
